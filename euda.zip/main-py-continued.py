reports_dir = os.path.join(args.directory, "reports")
                os.makedirs(reports_dir, exist_ok=True)
                
                for excel_file in excel_files:
                    report = generate_report(excel_file, session)
                    
                    # Save report to file
                    report_path = os.path.join(reports_dir, f"{os.path.splitext(excel_file.filename)[0]}_report.txt")
                    with open(report_path, 'w') as f:
                        f.write(report)
                
                print(f"Reports saved to: {reports_dir}")
        
        else:
            # No file or directory provided
            parser.print_help()
    
    finally:
        # Close the session
        session.close()

if __name__ == "__main__":
    main()
