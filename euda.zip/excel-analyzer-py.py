import os
import pandas as pd
import openpyxl
from openpyxl.packaging.manifest import ManifestParser

from excel.macro_analyzer import MacroAnalyzer
from excel.formula_analyzer import FormulaAnalyzer
from utils.helpers import calculate_complexity_score

class ExcelAnalyzer:
    """Class to analyze Excel files and extract information."""
    
    def __init__(self, file_path):
        """
        Initialize the Excel analyzer.
        
        Args:
            file_path (str): Path to the Excel file
        """
        self.file_path = file_path
        self.file_name = os.path.basename(file_path)
        self.file_size_kb = os.path.getsize(file_path) / 1024
        self.workbook = None
        self.macro_analyzer = None
        self.formula_analyzer = None
        
        # Load the workbook
        self._load_workbook()
        
    def _load_workbook(self):
        """Load the Excel workbook."""
        try:
            self.workbook = openpyxl.load_workbook(self.file_path, keep_vba=True, data_only=False)
            self.macro_analyzer = MacroAnalyzer(self.file_path, self.workbook)
            self.formula_analyzer = FormulaAnalyzer(self.workbook)
        except Exception as e:
            print(f"Error loading workbook: {str(e)}")
            raise
    
    def analyze(self):
        """
        Analyze the Excel file and return a dictionary with the analysis results.
        
        Returns:
            dict: Analysis results
        """
        if not self.workbook:
            raise ValueError("Workbook not loaded")
        
        # Extract basic file information
        sheet_names = self.workbook.sheetnames
        worksheet_count = len(sheet_names)
        
        # Analyze worksheets
        worksheets = []
        for sheet_name in sheet_names:
            sheet = self.workbook[sheet_name]
            
            # Get sheet properties
            visibility = "Visible"
            if sheet.sheet_state == "hidden":
                visibility = "Hidden"
            elif sheet.sheet_state == "veryHidden":
                visibility = "VeryHidden"
            
            # Calculate used range
            max_row = 0
            max_col = 0
            for row in sheet.rows:
                for cell in row:
                    if cell.value is not None:
                        max_row = max(max_row, cell.row)
                        max_col = max(max_col, cell.column)
            
            # Count formulas in the sheet
            formula_count = 0
            chart_count = 0
            table_count = 0
            
            for row in sheet.rows:
                for cell in row:
                    if cell.data_type == 'f':
                        formula_count += 1
            
            # Count charts
            if hasattr(sheet, '_charts'):
                chart_count = len(sheet._charts)
            
            # Count tables
            if hasattr(sheet, 'tables'):
                table_count = len(sheet.tables)
            
            # Add worksheet information
            worksheets.append({
                'name': sheet_name,
                'visibility': visibility,
                'row_count': max_row,
                'column_count': max_col,
                'formula_count': formula_count,
                'chart_count': chart_count,
                'table_count': table_count
            })
        
        # Analyze macros
        macros = self.macro_analyzer.analyze_macros()
        
        # Analyze formulas
        formulas = self.formula_analyzer.analyze_formulas()
        
        # Check for database connections
        connections = self._analyze_connections()
        
        # Calculate complexity score
        complexity_score = calculate_complexity_score(
            worksheet_count=worksheet_count,
            macro_count=len(macros),
            formula_count=len(formulas),
            connection_count=len(connections)
        )
        
        # Determine if the file can be remediated
        can_be_remediated = complexity_score < 7.5
        remediation_notes = self._generate_remediation_notes(
            complexity_score, macros, formulas, connections
        )
        
        # Generate file description
        file_description = self._generate_file_description(
            worksheet_count, macros, formulas, connections, complexity_score
        )
        
        return {
            'filename': self.file_name,
            'file_path': self.file_path,
            'file_size_kb': self.file_size_kb,
            'worksheet_count': worksheet_count,
            'complexity_score': complexity_score,
            'can_be_remediated': can_be_remediated,
            'remediation_notes': remediation_notes,
            'description': file_description,
            'worksheets': worksheets,
            'macros': macros,
            'formulas': formulas,
            'connections': connections
        }
    
    def _analyze_connections(self):
        """
        Analyze database connections in the Excel file.
        
        Returns:
            list: Database connections
        """
        connections = []
        
        # Check for external data connections in the workbook
        if hasattr(self.workbook, 'data_connections'):
            for conn in self.workbook.data_connections:
                connections.append({
                    'connection_type': 'Excel Data Connection',
                    'connection_string': conn.connection_string if hasattr(conn, 'connection_string') else '',
                    'target_database': '',  # Would need to parse connection string
                    'query_text': conn.command_text if hasattr(conn, 'command_text') else '',
                    'worksheet_name': ''  # Would need to map to sheet
                })
        
        # Look for connection information in defined names
        if hasattr(self.workbook, 'defined_names'):
            for name in self.workbook.defined_names.definedName:
                if 'connection' in name.name.lower() or 'odbc' in name.name.lower():
                    connections.append({
                        'connection_type': 'Named Range Connection',
                        'connection_string': name.value,
                        'target_database': '',
                        'query_text': '',
                        'worksheet_name': name.localSheetId if hasattr(name, 'localSheetId') else ''
                    })
        
        # Check for PowerQuery/Data Model connections (limited support in openpyxl)
        # This would require more advanced analysis
        
        return connections
    
    def _generate_remediation_notes(self, complexity_score, macros, formulas, connections):
        """
        Generate notes about how to remediate the Excel file with Python.
        
        Args:
            complexity_score (float): The calculated complexity score
            macros (list): List of macros
            formulas (list): List of formulas
            connections (list): List of database connections
            
        Returns:
            str: Remediation notes
        """
        notes = []
        
        if complexity_score >= 7.5:
            notes.append("This Excel file is highly complex and may require significant effort to remediate.")
        else:
            notes.append("This Excel file can likely be remediated with a Python application.")
        
        # Macro remediation
        if macros:
            notes.append("\nMacros remediation:")
            if len(macros) > 10:
                notes.append(f"- Contains {len(macros)} macros, which may be challenging to convert")
            else:
                notes.append(f"- Contains {len(macros)} macros that can be converted to Python functions")
                
            # Add specific macro suggestions
            for macro in macros[:3]:  # Limit to first 3 macros
                notes.append(f"- Macro '{macro['name']}' can be implemented using Python libraries")
        
        # Formula remediation
        if formulas:
            formula_types = {}
            for formula in formulas:
                if formula['formula_type'] in formula_types:
                    formula_types[formula['formula_type']] += 1
                else:
                    formula_types[formula['formula_type']] = 1
            
            notes.append("\nFormulas remediation:")
            for formula_type, count in formula_types.items():
                if formula_type == 'VLOOKUP':
                    notes.append(f"- {count} VLOOKUP formulas can be replaced with pandas merge/join operations")
                elif formula_type == 'INDEX' or formula_type == 'MATCH':
                    notes.append(f"- {count} INDEX/MATCH formulas can be replaced with pandas loc/iloc indexing")
                elif formula_type == 'SUM' or formula_type == 'AVERAGE':
                    notes.append(f"- {count} {formula_type} formulas can be replaced with pandas aggregate functions")
                else:
                    notes.append(f"- {count} {formula_type} formulas can be implemented with Python equivalents")
        
        # Database connection remediation
        if connections:
            notes.append("\nDatabase connections remediation:")
            notes.append(f"- {len(connections)} database connections can be replaced with SQLAlchemy or direct database connectors")
            for conn in connections[:2]:  # Limit to first 2 connections
                notes.append(f"- Connection to {conn['target_database'] or 'database'} can be implemented using SQLAlchemy")
        
        return "\n".join(notes)
    
    def _generate_file_description(self, worksheet_count, macros, formulas, connections, complexity_score):
        """
        Generate a description of the Excel file.
        
        Args:
            worksheet_count (int): Number of worksheets
            macros (list): List of macros
            formulas (list): List of formulas
            connections (list): List of database connections
            complexity_score (float): The calculated complexity score
            
        Returns:
            str: File description
        """
        complexity_text = "low"
        if complexity_score >= 7.5:
            complexity_text = "high"
        elif complexity_score >= 5:
            complexity_text = "medium"
        
        description = f"Excel file '{self.file_name}' with {worksheet_count} worksheets and {complexity_text} complexity ({complexity_score:.1f}/10). "
        
        if macros:
            description += f"Contains {len(macros)} macros including {', '.join([m['name'] for m in macros[:3]])}{'...' if len(macros) > 3 else ''}. "
        
        formula_types = {}
        for formula in formulas:
            if formula['formula_type'] in formula_types:
                formula_types[formula['formula_type']] += 1
            else:
                formula_types[formula['formula_type']] = 1
        
        if formula_types:
            formula_desc = ", ".join([f"{count} {ftype}" for ftype, count in list(formula_types.items())[:3]])
            description += f"Uses formulas including {formula_desc}{'...' if len(formula_types) > 3 else ''}. "
        
        if connections:
            description += f"Has {len(connections)} database connections. "
        
        if complexity_score < 7.5:
            description += "This file can likely be remediated with a Python application."
        else:
            description += "This file may be challenging to remediate due to its complexity."
        
        return description
