from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import ARRAY
from pgvector.sqlalchemy import Vector
import datetime

Base = declarative_base()

class ExcelFile(Base):
    __tablename__ = 'excel_files'
    
    id = Column(Integer, primary_key=True)
    filename = Column(String(255), nullable=False)
    file_path = Column(String(512), nullable=False)
    file_size_kb = Column(Integer, nullable=False)
    worksheet_count = Column(Integer, nullable=False)
    complexity_score = Column(Float, nullable=False)
    can_be_remediated = Column(Boolean, default=False)
    remediation_notes = Column(Text)
    analyzed_at = Column(DateTime, default=datetime.datetime.utcnow)
    description_embedding = Column(Vector(1536))  # Titan embedding dimensions
    
    # Relationships
    macros = relationship("Macro", back_populates="excel_file", cascade="all, delete-orphan")
    formulas = relationship("Formula", back_populates="excel_file", cascade="all, delete-orphan")
    connections = relationship("DatabaseConnection", back_populates="excel_file", cascade="all, delete-orphan")
    sheets = relationship("Worksheet", back_populates="excel_file", cascade="all, delete-orphan")

class Macro(Base):
    __tablename__ = 'macros'
    
    id = Column(Integer, primary_key=True)
    excel_file_id = Column(Integer, ForeignKey('excel_files.id'), nullable=False)
    name = Column(String(255), nullable=False)
    module_name = Column(String(255))
    line_count = Column(Integer, nullable=False)
    complexity_score = Column(Float, nullable=False)
    purpose_description = Column(Text)
    purpose_embedding = Column(Vector(1536))  # Titan embedding dimensions
    
    # Relationship
    excel_file = relationship("ExcelFile", back_populates="macros")

class Formula(Base):
    __tablename__ = 'formulas'
    
    id = Column(Integer, primary_key=True)
    excel_file_id = Column(Integer, ForeignKey('excel_files.id'), nullable=False)
    worksheet_name = Column(String(255), nullable=False)
    cell_reference = Column(String(50), nullable=False)
    formula_text = Column(Text, nullable=False)
    formula_type = Column(String(100))  # VLOOKUP, INDEX, MATCH, etc.
    complexity_score = Column(Float, nullable=False)
    formula_embedding = Column(Vector(1536))  # Titan embedding dimensions
    
    # Relationship
    excel_file = relationship("ExcelFile", back_populates="formulas")

class DatabaseConnection(Base):
    __tablename__ = 'database_connections'
    
    id = Column(Integer, primary_key=True)
    excel_file_id = Column(Integer, ForeignKey('excel_files.id'), nullable=False)
    connection_type = Column(String(100), nullable=False)  # ODBC, PowerQuery, etc.
    connection_string = Column(Text)
    target_database = Column(String(255))
    query_text = Column(Text)
    worksheet_name = Column(String(255))
    connection_embedding = Column(Vector(1536))  # Titan embedding dimensions
    
    # Relationship
    excel_file = relationship("ExcelFile", back_populates="connections")

class Worksheet(Base):
    __tablename__ = 'worksheets'
    
    id = Column(Integer, primary_key=True)
    excel_file_id = Column(Integer, ForeignKey('excel_files.id'), nullable=False)
    name = Column(String(255), nullable=False)
    visibility = Column(String(50), nullable=False)  # Visible, Hidden, VeryHidden
    row_count = Column(Integer, nullable=False)
    column_count = Column(Integer, nullable=False)
    formula_count = Column(Integer, nullable=False)
    chart_count = Column(Integer, nullable=False)
    table_count = Column(Integer, nullable=False)
    
    # Relationship
    excel_file = relationship("ExcelFile", back_populates="sheets")
