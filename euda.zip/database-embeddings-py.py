import boto3
import json
from config import AWS_CONFIG

class TitanEmbeddings:
    """Class to handle interactions with Amazon Titan Embedding model."""
    
    def __init__(self):
        """Initialize the Titan Embeddings client."""
        self.client = boto3.client(
            'bedrock-runtime',
            aws_access_key_id=AWS_CONFIG['access_key'],
            aws_secret_access_key=AWS_CONFIG['secret_key'],
            region_name=AWS_CONFIG['region']
        )
        self.model_id = AWS_CONFIG['embedding_model']

    def get_embedding(self, text):
        """
        Get embedding vector for a text using Amazon Titan Embedding model.
        
        Args:
            text (str): Text to get embeddings for
            
        Returns:
            list: Embedding vector
        """
        if not text:
            # Return zero vector if text is empty
            return [0.0] * 1536
            
        # Prepare the request payload
        request_body = {
            "inputText": text
        }
        
        # Convert to JSON string
        body = json.dumps(request_body)
        
        try:
            # Call the model
            response = self.client.invoke_model(
                modelId=self.model_id,
                body=body
            )
            
            # Parse the response
            response_body = json.loads(response.get('body').read())
            embedding = response_body.get('embedding')
            
            return embedding
        except Exception as e:
            print(f"Error getting embeddings: {str(e)}")
            # Return zero vector in case of error
            return [0.0] * 1536
