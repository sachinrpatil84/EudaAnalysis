'line_count': line_count,
                'complexity_score': complexity_score,
                'purpose_description': purpose,
                'type': 'Function'
            })
    
    def _extract_macro_purpose(self, macro_code):
        """
        Extract the purpose of a macro from its comments or code.
        
        Args:
            macro_code (str): VBA macro code
            
        Returns:
            str: Purpose description
        """
        # Look for comments at the beginning of the macro
        lines = macro_code.split('\n')
        comment_lines = []
        
        for line in lines[1:]:  # Skip the Sub/Function line
            line = line.strip()
            if line.startswith("'") or line.startswith("REM "):
                # Extract the comment text
                if line.startswith("'"):
                    comment_lines.append(line[1:].strip())
                else:  # REM comment
                    comment_lines.append(line[4:].strip())
            elif line and not line.startswith("'") and not line.startswith("REM "):
                # Stop at the first non-comment line
                break
        
        if comment_lines:
            return " ".join(comment_lines)
        
        # If no comments found, try to derive purpose from code
        code_purpose = self._derive_purpose_from_code(macro_code)
        if code_purpose:
            return code_purpose
        
        # Default purpose
        if "Sub " in macro_code:
            return f"VBA Subroutine: {lines[0]}"
        else:
            return f"VBA Function: {lines[0]}"
    
    def _derive_purpose_from_code(self, macro_code):
        """
        Derive the purpose of a macro from its code.
        
        Args:
            macro_code (str): VBA macro code
            
        Returns:
            str: Derived purpose
        """
        # Look for common patterns to determine purpose
        lower_code = macro_code.lower()
        
        if "worksheet" in lower_code and "protect" in lower_code:
            return "Protects or unprotects worksheets"
        
        if "mail" in lower_code or "outlook" in lower_code or "smtp" in lower_code:
            return "Sends emails or interacts with Outlook"
        
        if "database" in lower_code or "adodb" in lower_code or "connection" in lower_code:
            return "Connects to or queries a database"
        
        if "report" in lower_code and ("generate" in lower_code or "create" in lower_code):
            return "Generates reports"
        
        if "print" in lower_code:
            return "Handles printing functionality"
        
        if "import" in lower_code or "export" in lower_code:
            return "Imports or exports data"
        
        if "calculate" in lower_code or "computation" in lower_code:
            return "Performs calculations"
        
        if "format" in lower_code and ("cell" in lower_code or "range" in lower_code):
            return "Formats cells or ranges"
        
        if "userform" in lower_code:
            return "Handles UserForm interactions"
        
        # Default: unknown purpose
        return "Purpose could not be determined automatically"
