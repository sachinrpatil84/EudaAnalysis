import os
import zipfile
import re
from xml.etree import ElementTree as ET
from utils.helpers import calculate_macro_complexity

class MacroAnalyzer:
    """Class to analyze VBA macros in Excel files."""
    
    def __init__(self, file_path, workbook=None):
        """
        Initialize the Macro Analyzer.
        
        Args:
            file_path (str): Path to the Excel file
            workbook (openpyxl.Workbook, optional): Loaded workbook
        """
        self.file_path = file_path
        self.workbook = workbook
        self.macros = []
    
    def has_macros(self):
        """
        Check if the Excel file contains macros.
        
        Returns:
            bool: True if the file contains macros, False otherwise
        """
        # Check file extension
        if self.file_path.endswith('.xlsm') or self.file_path.endswith('.xls'):
            return True
        
        # Check for VBA project
        if self.workbook and hasattr(self.workbook, 'vba_archive'):
            return True
        
        # Try to extract macros
        try:
            with zipfile.ZipFile(self.file_path, 'r') as zip_ref:
                vba_files = [f for f in zip_ref.namelist() if 'vba' in f.lower()]
                return len(vba_files) > 0
        except:
            return False
    
    def analyze_macros(self):
        """
        Analyze macros in the Excel file.
        
        Returns:
            list: List of dictionaries with macro information
        """
        if not self.has_macros():
            return []
        
        self.macros = []
        
        # Try to analyze VBA project using openpyxl
        if self.workbook and hasattr(self.workbook, 'vba_archive'):
            self._analyze_with_openpyxl()
        
        # If no macros found, try to extract VBA code from the file
        if not self.macros:
            self._analyze_with_zipfile()
        
        return self.macros
    
    def _analyze_with_openpyxl(self):
        """Analyze macros using openpyxl."""
        try:
            # Extract VBA modules
            for vba_module in self.workbook.vba_archive.getnames():
                if vba_module.endswith('.bin'):
                    continue
                
                module_name = os.path.basename(vba_module)
                if not module_name:
                    continue
                
                # Get VBA code
                try:
                    vba_code = self.workbook.vba_archive.read(vba_module).decode('utf-8', errors='ignore')
                except:
                    continue
                
                # Extract macros from VBA code
                self._extract_macros_from_code(vba_code, module_name)
        except Exception as e:
            print(f"Error analyzing VBA with openpyxl: {str(e)}")
    
    def _analyze_with_zipfile(self):
        """Analyze macros by extracting from ZIP file."""
        try:
            with zipfile.ZipFile(self.file_path, 'r') as zip_ref:
                # Find VBA files
                vba_files = [f for f in zip_ref.namelist() if 'vba' in f.lower()]
                
                for vba_file in vba_files:
                    module_name = os.path.basename(vba_file)
                    if not module_name:
                        continue
                    
                    # Get VBA code
                    try:
                        vba_code = zip_ref.read(vba_file).decode('utf-8', errors='ignore')
                    except:
                        continue
                    
                    # Extract macros from VBA code
                    self._extract_macros_from_code(vba_code, module_name)
        except Exception as e:
            print(f"Error analyzing VBA with zipfile: {str(e)}")
    
    def _extract_macros_from_code(self, vba_code, module_name):
        """
        Extract macros from VBA code.
        
        Args:
            vba_code (str): VBA code
            module_name (str): Name of the VBA module
        """
        # Regular expressions to find macros
        sub_pattern = r'(?i)Sub\s+([^\(]+)(?:\([^\)]*\))?\s*\n(.*?)(?i)End\s+Sub'
        function_pattern = r'(?i)Function\s+([^\(]+)(?:\([^\)]*\))?\s*\n(.*?)(?i)End\s+Function'
        
        # Find all Sub procedures
        for match in re.finditer(sub_pattern, vba_code, re.DOTALL):
            macro_name = match.group(1).strip()
            macro_code = match.group(0)
            
            # Calculate line count
            line_count = macro_code.count('\n') + 1
            
            # Calculate complexity
            complexity_score = calculate_macro_complexity(macro_code)
            
            # Extract purpose
            purpose = self._extract_macro_purpose(macro_code)
            
            self.macros.append({
                'name': macro_name,
                'module_name': module_name,
                'line_count': line_count,
                'complexity_score': complexity_score,
                'purpose_description': purpose,
                'type': 'Sub'
            })
        
        # Find all Functions
        for match in re.finditer(function_pattern, vba_code, re.DOTALL):
            function_name = match.group(1).strip()
            function_code = match.group(0)
            
            # Calculate line count
            line_count = function_code.count('\n') + 1
            
            # Calculate complexity
            complexity_score = calculate_macro_complexity(function_code)
            
            # Extract purpose
            purpose = self._extract_macro_purpose(function_code)
            
            self.macros.append({
                'name': function_name,
                'module_name': module_name,
                'line_count