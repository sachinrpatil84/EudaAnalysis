import re
from utils.helpers import calculate_formula_complexity

class FormulaAnalyzer:
    """Class to analyze Excel formulas."""
    
    def __init__(self, workbook):
        """
        Initialize the Formula Analyzer.
        
        Args:
            workbook (openpyxl.Workbook): Loaded workbook
        """
        self.workbook = workbook
        self.formulas = []
        
        # Common Excel formula functions
        self.formula_types = {
            'VLOOKUP': r'VLOOKUP\s*\(',
            'INDEX': r'INDEX\s*\(',
            'MATCH': r'MATCH\s*\(',
            'SUMIF': r'SUMIF\s*\(',
            'SUMIFS': r'SUMIFS\s*\(',
            'COUNTIF': r'COUNTIF\s*\(',
            'COUNTIFS': r'COUNTIFS\s*\(',
            'IF': r'IF\s*\(',
            'IFERROR': r'IFERROR\s*\(',
            'AVERAGEIF': r'AVERAGEIF\s*\(',
            'AVERAGEIFS': r'AVERAGEIFS\s*\(',
            'SUM': r'SUM\s*\(',
            'AVERAGE': r'AVERAGE\s*\(',
            'MIN': r'MIN\s*\(',
            'MAX': r'MAX\s*\(',
            'CONCATENATE': r'CONCATENATE\s*\(',
            'OFFSET': r'OFFSET\s*\(',
            'INDIRECT': r'INDIRECT\s*\(',
            'SUBSTITUTE': r'SUBSTITUTE\s*\(',
            'LEFT': r'LEFT\s*\(',
            'RIGHT': r'RIGHT\s*\(',
            'MID': r'MID\s*\(',
            'LEN': r'LEN\s*\(',
            'FIND': r'FIND\s*\(',
            'SEARCH': r'SEARCH\s*\(',
            'TEXT': r'TEXT\s*\(',
            'VALUE': r'VALUE\s*\(',
            'DATE': r'DATE\s*\(',
            'DATEVALUE': r'DATEVALUE\s*\(',
            'TODAY': r'TODAY\s*\(',
            'NOW': r'NOW\s*\(',
            'NETWORKDAYS': r'NETWORKDAYS\s*\(',
            'WORKDAY': r'WORKDAY\s*\(',
            'MONTH': r'MONTH\s*\(',
            'YEAR': r'YEAR\s*\(',
            'DAY': r'DAY\s*\(',
            'WEEKDAY': r'WEEKDAY\s*\(',
            'LOOKUP': r'LOOKUP\s*\(',
            'HLOOKUP': r'HLOOKUP\s*\(',
            'CHOOSE': r'CHOOSE\s*\(',
            'TRANSPOSE': r'TRANSPOSE\s*\(',
            'SUBTOTAL': r'SUBTOTAL\s*\(',
            'HYPERLINK': r'HYPERLINK\s*\(',
            'ROUND': r'ROUND\s*\(',
            'ROUNDUP': r'ROUNDUP\s*\(',
            'ROUNDDOWN': r'ROUNDDOWN\s*\(',
            'POWER': r'POWER\s*\(',
            'RANDBETWEEN': r'RANDBETWEEN\s*\(',
            'AND': r'AND\s*\(',
            'OR': r'OR\s*\(',
            'NOT': r'NOT\s*\(',
            'TRUE': r'TRUE\s*\(',
            'FALSE': r'FALSE\s*\(',
            'ARRAY': r'\{.*\}',  # Array formula
            'DB_QUERY': r'(ODBC|SQL|Query)'  # Database query related
        }
    
    def analyze_formulas(self):
        """
        Analyze formulas in the Excel workbook.
        
        Returns:
            list: List of dictionaries with formula information
        """
        self.formulas = []
        
        for sheet_name in self.workbook.sheetnames:
            sheet = self.workbook[sheet_name]
            
            for row in sheet.rows:
                for cell in row:
                    if cell.data_type == 'f':
                        formula = cell.value
                        if formula:
                            formula_type = self._determine_formula_type(formula)
                            complexity_score = calculate_formula_complexity(formula)
                            
                            self.formulas.append({
                                'worksheet_name': sheet_name,
                                'cell_reference': cell.coordinate,
                                'formula_text': formula,
                                'formula_type': formula_type,
                                'complexity_score': complexity_score
                            })
        
        return self.formulas
    
    def _determine_formula_type(self, formula):
        """
        Determine the type of an Excel formula.
        
        Args:
            formula (str): Excel formula
            
        Returns:
            str: Formula type
        """
        formula = formula.upper()
        
        for formula_type, pattern in self.formula_types.items():
            if re.search(pattern, formula, re.IGNORECASE):
                return formula_type
        
        # If no specific type is found
        if "=" in formula:
            return "BASIC"
        
        return "OTHER"
