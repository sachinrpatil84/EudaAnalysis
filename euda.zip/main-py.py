import os
import argparse
import pandas as pd
from pathlib import Path
import traceback
import time

from database.connection import get_db_session
from database.models import ExcelFile, Macro, Formula, DatabaseConnection, Worksheet
from database.embeddings import TitanEmbeddings
from excel.analyzer import ExcelAnalyzer
from utils.helpers import format_file_size


def analyze_excel_file(file_path, embed_client=None):
    """
    Analyze an Excel file and return the analysis results.
    
    Args:
        file_path (str): Path to the Excel file
        embed_client (TitanEmbeddings, optional): Client for generating embeddings
        
    Returns:
        dict: Analysis results
    """
    print(f"Analyzing file: {file_path}")
    start_time = time.time()
    
    analyzer = ExcelAnalyzer(file_path)
    results = analyzer.analyze()
    
    # Generate embeddings if client is provided
    if embed_client:
        # Generate embedding for file description
        if results.get('description'):
            results['description_embedding'] = embed_client.get_embedding(results['description'])
        
        # Generate embeddings for macros
        for macro in results.get('macros', []):
            if macro.get('purpose_description'):
                macro['purpose_embedding'] = embed_client.get_embedding(macro['purpose_description'])
        
        # Generate embeddings for formulas
        for formula in results.get('formulas', []):
            formula['formula_embedding'] = embed_client.get_embedding(formula['formula_text'])
        
        # Generate embeddings for connections
        for conn in results.get('connections', []):
            conn_text = f"{conn['connection_type']} connecting to {conn['target_database']} with query {conn['query_text']}"
            conn['connection_embedding'] = embed_client.get_embedding(conn_text)
    
    duration = time.time() - start_time
    print(f"Analysis completed in {duration:.2f} seconds")
    
    return results

def save_to_database(analysis_results, session):
    """
    Save analysis results to the database.
    
    Args:
        analysis_results (dict): Analysis results
        session (sqlalchemy.Session): Database session
        
    Returns:
        ExcelFile: Saved Excel file record
    """
    # Create Excel file record
    excel_file = ExcelFile(
        filename=analysis_results['filename'],
        file_path=analysis_results['file_path'],
        file_size_kb=analysis_results['file_size_kb'],
        worksheet_count=analysis_results['worksheet_count'],
        complexity_score=analysis_results['complexity_score'],
        can_be_remediated=analysis_results['can_be_remediated'],
        remediation_notes=analysis_results['remediation_notes'],
        description_embedding=analysis_results.get('description_embedding')
    )
    
    # Add worksheets
    for ws_data in analysis_results.get('worksheets', []):
        worksheet = Worksheet(
            name=ws_data['name'],
            visibility=ws_data['visibility'],
            row_count=ws_data['row_count'],
            column_count=ws_data['column_count'],
            formula_count=ws_data['formula_count'],
            chart_count=ws_data['chart_count'],
            table_count=ws_data['table_count']
        )
        excel_file.sheets.append(worksheet)
    
    # Add macros
    for macro_data in analysis_results.get('macros', []):
        macro = Macro(
            name=macro_data['name'],
            module_name=macro_data['module_name'],
            line_count=macro_data['line_count'],
            complexity_score=macro_data['complexity_score'],
            purpose_description=macro_data['purpose_description'],
            purpose_embedding=macro_data.get('purpose_embedding')
        )
        excel_file.macros.append(macro)
    
    # Add formulas
    for formula_data in analysis_results.get('formulas', []):
        formula = Formula(
            worksheet_name=formula_data['worksheet_name'],
            cell_reference=formula_data['cell_reference'],
            formula_text=formula_data['formula_text'],
            formula_type=formula_data['formula_type'],
            complexity_score=formula_data['complexity_score'],
            formula_embedding=formula_data.get('formula_embedding')
        )
        excel_file.formulas.append(formula)
    
    # Add database connections
    for conn_data in analysis_results.get('connections', []):
        connection = DatabaseConnection(
            connection_type=conn_data['connection_type'],
            connection_string=conn_data.get('connection_string', ''),
            target_database=conn_data.get('target_database', ''),
            query_text=conn_data.get('query_text', ''),
            worksheet_name=conn_data.get('worksheet_name', ''),
            connection_embedding=conn_data.get('connection_embedding')
        )
        excel_file.connections.append(connection)
    
    # Save to database
    session.add(excel_file)
    session.commit()
    
    return excel_file

def generate_report(excel_file, session):
    """
    Generate a report for an analyzed Excel file.
    
    Args:
        excel_file (ExcelFile): Excel file record
        session (sqlalchemy.Session): Database session
        
    Returns:
        str: Report text
    """
    report = []
    report.append(f"EXCEL FILE ANALYSIS REPORT: {excel_file.filename}")
    report.append("=" * 80)
    report.append(f"File path: {excel_file.file_path}")
    report.append(f"File size: {format_file_size(excel_file.file_size_kb * 1024)}")
    report.append(f"Worksheets: {excel_file.worksheet_count}")
    report.append(f"Complexity score: {excel_file.complexity_score:.2f}/10")
    report.append(f"Can be remediated: {'Yes' if excel_file.can_be_remediated else 'No'}")
    report.append("\nREMEDIATION NOTES:")
    report.append("-" * 80)
    report.append(excel_file.remediation_notes)
    
    # Add macros summary
    macros = session.query(Macro).filter(Macro.excel_file_id == excel_file.id).all()
    if macros:
        report.append("\nMACROS SUMMARY:")
        report.append("-" * 80)
        report.append(f"Total macros: {len(macros)}")
        
        # Top 5 most complex macros
        complex_macros = sorted(macros, key=lambda m: m.complexity_score, reverse=True)[:5]
        if complex_macros:
            report.append("\nTop 5 most complex macros:")
            for i, macro in enumerate(complex_macros, 1):
                report.append(f"{i}. {macro.name} (Complexity: {macro.complexity_score:.2f})")
                report.append(f"   Module: {macro.module_name}")
                report.append(f"   Lines: {macro.line_count}")
                report.append(f"   Purpose: {macro.purpose_description}")
    
    # Add formulas summary
    formulas = session.query(Formula).filter(Formula.excel_file_id == excel_file.id).all()
    if formulas:
        report.append("\nFORMULAS SUMMARY:")
        report.append("-" * 80)
        report.append(f"Total formulas: {len(formulas)}")
        
        # Group formulas by type
        formula_types = {}
        for formula in formulas:
            if formula.formula_type in formula_types:
                formula_types[formula.formula_type] += 1
            else:
                formula_types[formula.formula_type] = 1
        
        # Sort by frequency
        formula_types = {k: v for k, v in sorted(formula_types.items(), key=lambda item: item[1], reverse=True)}
        
        report.append("\nFormula types:")
        for formula_type, count in formula_types.items():
            report.append(f"- {formula_type}: {count}")
    
    # Add database connections summary
    connections = session.query(DatabaseConnection).filter(DatabaseConnection.excel_file_id == excel_file.id).all()
    if connections:
        report.append("\nDATABASE CONNECTIONS SUMMARY:")
        report.append("-" * 80)
        report.append(f"Total connections: {len(connections)}")
        
        for i, conn in enumerate(connections, 1):
            report.append(f"{i}. Connection type: {conn.connection_type}")
            if conn.target_database:
                report.append(f"   Target database: {conn.target_database}")
            if conn.query_text:
                report.append(f"   Query: {conn.query_text[:100]}{'...' if len(conn.query_text) > 100 else ''}")
    
    # Add worksheets summary
    worksheets = session.query(Worksheet).filter(Worksheet.excel_file_id == excel_file.id).all()
    if worksheets:
        report.append("\nWORKSHEETS SUMMARY:")
        report.append("-" * 80)
        
        for i, ws in enumerate(worksheets, 1):
            report.append(f"{i}. {ws.name} ({ws.visibility})")
            report.append(f"   Dimensions: {ws.row_count} rows x {ws.column_count} columns")
            report.append(f"   Formulas: {ws.formula_count}, Charts: {ws.chart_count}, Tables: {ws.table_count}")
    
    return "\n".join(report)

def find_similar_excel_files(file_id, session, limit=5):
    """
    Find similar Excel files based on vector embeddings.
    
    Args:
        file_id (int): Excel file ID
        session (sqlalchemy.Session): Database session
        limit (int, optional): Maximum number of similar files to return
        
    Returns:
        list: Similar Excel files with similarity scores
    """
    # Get the file embedding
    file = session.query(ExcelFile).filter(ExcelFile.id == file_id).first()
    if not file or file.description_embedding is None:
        return []
    
    # Find similar files using vector similarity
    similar_files = session.execute("""
        SELECT 
            id, 
            filename, 
            complexity_score,
            can_be_remediated,
            1 - (description_embedding <=> :embedding) AS similarity
        FROM 
            excel_files
        WHERE 
            id != :file_id
        ORDER BY 
            similarity DESC
        LIMIT :limit
    """, {
        'embedding': file.description_embedding,
        'file_id': file_id,
        'limit': limit
    }).fetchall()
    
    return similar_files

def analyze_directory(directory_path, db_session, embed_client=None):
    """
    Analyze all Excel files in a directory.
    
    Args:
        directory_path (str): Path to the directory
        db_session (sqlalchemy.Session): Database session
        embed_client (TitanEmbeddings, optional): Client for generating embeddings
        
    Returns:
        list: Analyzed Excel files
    """
    excel_files = []
    
    # Walk through the directory
    for root, _, files in os.walk(directory_path):
        for file in files:
            if file.endswith(('.xlsx', '.xlsm', '.xls')) and not file.startswith('~$'):
                file_path = os.path.join(root, file)
                try:
                    # Analyze the file
                    results = analyze_excel_file(file_path, embed_client)
                    
                    # Save to database
                    excel_file = save_to_database(results, db_session)
                    excel_files.append(excel_file)
                    
                    print(f"Successfully analyzed and saved: {file}")
                except Exception as e:
                    print(f"Error analyzing file {file}: {str(e)}")
                    traceback.print_exc()
    
    return excel_files

def main():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Analyze Excel files to determine complexity and remediation potential')
    parser.add_argument('--file', help='Path to a single Excel file to analyze')
    parser.add_argument('--directory', help='Path to a directory containing Excel files to analyze')
    parser.add_argument('--report', action='store_true', help='Generate a report for each analyzed file')
    parser.add_argument('--no-embeddings', action='store_true', help='Skip vector embeddings generation')
    args = parser.parse_args()
    
    # Create database session
    session = get_db_session()
    
    # Initialize embedding client if needed
    embed_client = None
    if not args.no_embeddings:
        try:
            embed_client = TitanEmbeddings()
        except Exception as e:
            print(f"Warning: Could not initialize embedding client: {str(e)}")
            print("Continuing without embeddings...")
    
    try:
        if args.file:
            # Analyze a single file
            if not os.path.isfile(args.file):
                print(f"Error: File not found: {args.file}")
                return
            
            results = analyze_excel_file(args.file, embed_client)
            excel_file = save_to_database(results, session)
            
            print(f"Successfully analyzed and saved: {args.file}")
            
            if args.report:
                report = generate_report(excel_file, session)
                print("\n" + report)
                
                # Save report to file
                report_path = f"{os.path.splitext(args.file)[0]}_report.txt"
                with open(report_path, 'w') as f:
                    f.write(report)
                print(f"Report saved to: {report_path}")
                
                # Find similar files
                similar_files = find_similar_excel_files(excel_file.id, session)
                if similar_files:
                    print("\nSimilar Excel files:")
                    for i, (id, filename, complexity, can_remediate, similarity) in enumerate(similar_files, 1):
                        print(f"{i}. {filename} (Similarity: {similarity:.2f}, Complexity: {complexity:.2f})")
        
        elif args.directory:
            # Analyze all Excel files in a directory
            if not os.path.isdir(args.directory):
                print(f"Error: Directory not found: {args.directory}")
                return
            
            excel_files = analyze_directory(args.directory, session, embed_client)
            
            print(f"\nSuccessfully analyzed {len(excel_files)} Excel files")
            
            if args.report and excel_files:
                # Create reports directory
                reports_dir = os.path.join(args.directory, "reports")
                os.makedirs(reports_dir, exist