import re

def calculate_complexity_score(worksheet_count, macro_count, formula_count, connection_count):
    """
    Calculate a complexity score for an Excel file.
    
    Args:
        worksheet_count (int): Number of worksheets
        macro_count (int): Number of macros
        formula_count (int): Number of complex formulas
        connection_count (int): Number of database connections
        
    Returns:
        float: Complexity score between 1 and 10
    """
    # Base score
    score = 1.0
    
    # Worksheet complexity (max 2 points)
    if worksheet_count <= 3:
        score += 0.5
    elif worksheet_count <= 10:
        score += 1.0
    else:
        score += 2.0
    
    # Macro complexity (max 3 points)
    if macro_count == 0:
        score += 0
    elif macro_count <= 5:
        score += 1.0
    elif macro_count <= 15:
        score += 2.0
    else:
        score += 3.0
    
    # Formula complexity (max 3 points)
    if formula_count == 0:
        score += 0
    elif formula_count <= 10:
        score += 0.5
    elif formula_count <= 50:
        score += 1.5
    elif formula_count <= 100:
        score += 2.0
    else:
        score += 3.0
    
    # Connection complexity (max 2 points)
    if connection_count == 0:
        score += 0
    elif connection_count == 1:
        score += 1.0
    else:
        score += 2.0
    
    return min(score, 10.0)

def calculate_macro_complexity(macro_code):
    """
    Calculate the complexity of a VBA macro.
    
    Args:
        macro_code (str): VBA macro code
        
    Returns:
        float: Complexity score between 1 and 10
    """
    # Base score
    score = 1.0
    
    # Line count
    line_count = macro_code.count('\n') + 1
    if line_count <= 10:
        score += 0.5
    elif line_count <= 50:
        score += 1.5
    elif line_count <= 100:
        score += 2.5
    else:
        score += 3.5
    
    # Control structures
    if_count = len(re.findall(r'(?i)\bIf\b', macro_code))
    loop_count = (
        len(re.findall(r'(?i)\bFor\b', macro_code)) +
        len(re.findall(r'(?i)\bDo\b', macro_code)) +
        len(re.findall(r'(?i)\bWhile\b', macro_code))
    )
    select_count = len(re.findall(r'(?i)\bSelect\s+Case\b', macro_code))
    
    control_score = min(3.0, (if_count * 0.2) + (loop_count * 0.3) + (select_count * 0.5))
    score += control_score
    
    # External interactions
    external_score = 0
    if re.search(r'(?i)\bConnection\b|\bADODB\b|\bSQL\b', macro_code):
        external_score += 1.5
    if re.search(r'(?i)\bOutlook\b|\bMail\b|\bSMTP\b', macro_code):
        external_score += 1.0
    if re.search(r'(?i)\bFile\b|\bFSO\b|\bFileSystemObject\b', macro_code):
        external_score += 0.8
    
    score += min(2.5, external_score)
    
    return min(score, 10.0)

def calculate_formula_complexity(formula):
    """
    Calculate the complexity of an Excel formula.
    
    Args:
        formula (str): Excel formula
        
    Returns:
        float: Complexity score between 1 and 10
    """
    # Base score
    score = 1.0
    
    # Length of formula
    if len(formula) <= 20:
        score += 0.5
    elif len(formula) <= 50:
        score += 1.0
    elif len(formula) <= 100:
        score += 2.0
    else:
        score += 3.0
    
    # Nested functions (count opening parentheses)
    nesting_level = 0
    max_nesting = 0
    for char in formula:
        if char == '(':
            nesting_level += 1
            max_nesting = max(max_nesting, nesting_level)
        elif char == ')':
            nesting_level = max(0, nesting_level - 1)
    
    if max_nesting <= 1:
        score += 0.5
    elif max_nesting <= 3:
        score += 1.5
    elif max_nesting <= 5:
        score += 2.5
    else:
        score += 3.5
    
    # Complex functions
    complex_functions = [
        'VLOOKUP', 'INDEX', 'MATCH', 'INDIRECT', 'OFFSET',
        'SUMIFS', 'COUNTIFS', 'AVERAGEIFS', 'SUMPRODUCT',
        'IFERROR', 'IFNA', 'CHOOSE', 'LOOKUP'
    ]
    
    complex_count = 0
    for func in complex_functions:
        complex_count += formula.upper().count(func)
    
    if complex_count == 0:
        score += 0
    elif complex_count == 1:
        score += 0.5
    elif complex_count <= 3:
        score += 1.5
    else:
        score += 2.5
    
    return min(score, 10.0)

def format_file_size(size_bytes):
    """
    Format file size from bytes to human-readable format.
    
    Args:
        size_bytes (int): Size in bytes
        
    Returns:
        str: Formatted file size
    """
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.2f} PB"
