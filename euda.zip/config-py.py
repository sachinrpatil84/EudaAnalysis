import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Database configuration
DB_CONFIG = {
    'host': os.getenv('DB_HOST', 'localhost'),
    'port': os.getenv('DB_PORT', '5432'),
    'database': os.getenv('DB_NAME', 'euda_analyzer'),
    'user': os.getenv('DB_USER', 'postgres'),
    'password': os.getenv('DB_PASSWORD', 'your_password')
}

# AWS configuration for Titan embedding model
AWS_CONFIG = {
    'access_key': os.getenv('AWS_ACCESS_KEY_ID'),
    'secret_key': os.getenv('AWS_SECRET_ACCESS_KEY'),
    'region': os.getenv('AWS_REGION', 'us-east-1'),
    'embedding_model': 'amazon-titan-embed-text-2:0'
}

# Application configuration
APP_CONFIG = {
    'max_file_size_mb': 50,  # Maximum Excel file size in MB
    'supported_extensions': ['.xlsx', '.xlsm', '.xls'],
    'embedding_dimensions': 1536  # Titan embedding dimensions
}
