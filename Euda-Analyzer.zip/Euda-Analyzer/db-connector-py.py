import psycopg2
from psycopg2.extras import execute_values
from sqlalchemy import create_engine
from src.config import DB_CONFIG
import logging

logger = logging.getLogger(__name__)

class DatabaseConnector:
    """Handles connections to the PostgreSQL database."""
    
    def __init__(self):
        """Initialize database connection parameters."""
        self.host = DB_CONFIG['host']
        self.port = DB_CONFIG['port']
        self.user = DB_CONFIG['user']
        self.password = DB_CONFIG['password']
        self.database = DB_CONFIG['database']
        self.conn = None
        self.engine = None
        
    def get_connection_string(self):
        """Get SQLAlchemy connection string."""
        return f"postgresql://{self.user}:{self.password}@{self.host}:{self.port}/{self.database}"
        
    def connect(self):
        """Establish a connection to the database."""
        try:
            # Connect to PostgreSQL
            self.conn = psycopg2.connect(
                host=self.host,
                port=self.port,
                user=self.user,
                password=self.password,
                database=self.database
            )
            logger.info("Successfully connected to PostgreSQL database")
            return self.conn
        except Exception as e:
            logger.error(f"Error connecting to database: {e}")
            raise
            
    def get_sqlalchemy_engine(self):
        """Get a SQLAlchemy engine for the database."""
        if not self.engine:
            conn_string = self.get_connection_string()
            self.engine = create_engine(conn_string)
        return self.engine
        
    def execute_query(self, query, params=None):
        """Execute a SQL query and return results."""
        if not self.conn or self.conn.closed:
            self.connect()
            
        try:
            with self.conn.cursor() as cursor:
                if params:
                    cursor.execute(query, params)
                else:
                    cursor.execute(query)
                    
                # Check if query is a SELECT query
                if cursor.description:
                    return cursor.fetchall()
                else:
                    self.conn.commit()
                    return cursor.rowcount
        except Exception as e:
            self.conn.rollback()
            logger.error(f"Error executing query: {e}")
            raise
            
    def execute_batch(self, query, params_list):
        """Execute a batch insert operation."""
        if not self.conn or self.conn.closed:
            self.connect()
            
        try:
            with self.conn.cursor() as cursor:
                execute_values(cursor, query, params_list)
                self.conn.commit()
                return cursor.rowcount
        except Exception as e:
            self.conn.rollback()
            logger.error(f"Error executing batch query: {e}")
            raise
            
    def close(self):
        """Close the database connection."""
        if self.conn and not self.conn.closed:
            self.conn.close()
            logger.info("Database connection closed")
