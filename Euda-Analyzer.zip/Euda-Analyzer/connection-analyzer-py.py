import re
import os
import logging
import openpyxl
try:
    import win32com.client
    HAS_WIN32COM = True
except ImportError:
    HAS_WIN32COM = False

logger = logging.getLogger(__name__)

class ConnectionAnalyzer:
    """Class for analyzing external data connections in Excel files."""
    
    def __init__(self, file_path):
        """Initialize with the path to an Excel file."""
        self.file_path = file_path
        self.excel_app = None
        self.connections = []
        
    def analyze(self):
        """Analyze the external connections in the Excel file."""
        # Try to analyze with win32com first (if available)
        if HAS_WIN32COM:
            try:
                self._analyze_with_win32com()
            except Exception as e:
                logger.warning(f"Win32com connection analysis failed: {e}")
                self._analyze_with_openpyxl()
        else:
            # Fallback to openpyxl analysis
            self._analyze_with_openpyxl()
            
        # Additional analysis for connection strings in formulas and VBA
        self._analyze_connection_patterns()
        
        logger.info(f"Analyzed {len(self.connections)} connections in {self.file_path}")
        return self.connections
        
    def _analyze_with_win32com(self):
        """Analyze connections using win32com (Windows only)."""
        try:
            # Initialize Excel application
            self.excel_app = win32com.client.Dispatch("Excel.Application")
            self.excel_app.Visible = False
            self.excel_app.DisplayAlerts = False
            
            # Open the workbook
            workbook = self.excel_app.Workbooks.Open(self.file_path)
            
            # Check for external data connections
            for connection in workbook.Connections:
                conn_info = {
                    'connection_type': 'External Data Connection',
                    'connection_string': connection.ODBCConnection.Connection if hasattr(connection, 'ODBCConnection') else str(connection),
                    'target_resource': self._extract_target_from_connection(connection.ODBCConnection.Connection if hasattr(connection, 'ODBCConnection') else str(connection)),
                    'sensitivity_level': self._assess_connection_sensitivity(connection.ODBCConnection.Connection if hasattr(connection, 'ODBCConnection') else str(connection))
                }
                self.connections.append(conn_info)
                
            # Check for query tables (another form of connection)
            for sheet in workbook.Sheets:
                if hasattr(sheet, 'QueryTables'):
                    for query in sheet.QueryTables:
                        conn_info = {
                            'connection_type': 'Query Table',
                            'connection_string': query.Connection,
                            'target_resource': self._extract_target_from_connection(query.Connection),
                            'sensitivity_level': self._assess_connection_sensitivity(query.Connection)
                        }
                        self.connections.append(conn_info)
                        
            # Check for pivot caches (another data source)
            for pivot_cache in workbook.PivotCaches():
                if hasattr(pivot_cache, 'Connection'):
                    conn_info = {
                        'connection_type': 'Pivot Cache',
                        'connection_string': pivot_cache.Connection,
                        'target_resource': self._extract_target_from_connection(pivot_cache.Connection),
                        'sensitivity_level': self._assess_connection_sensitivity(pivot_cache.Connection)
                    }
                    self.connections.append(conn_info)
                    
            # Close workbook and quit Excel
            workbook.Close(SaveChanges=False)
            self.excel_app.Quit()
            
        except Exception as e:
            logger.error(f"Error in win32com connection analysis: {e}")
            if self.excel_app:
                try:
                    self.excel_app.Quit()
                except:
                    pass
            raise
            
    def _analyze_with_openpyxl(self):
        """Analyze connections using openpyxl (cross-platform)."""
        try:
            # Load workbook
            workbook = openpyxl.load_workbook(self.file_path, data_only=False)
            
            # Check for external links
            if hasattr(workbook, '_external_links'):
                for link in workbook._external_links:
                    conn_info = {
                        'connection_type': 'External Link',
                        'connection_string': str(link),
                        'target_resource': self._extract_target_from_link(link),
                        'sensitivity_level': 'medium'  # Default for external links
                    }
                    self.connections.append(conn_info)
                    
            # Check for defined names that might contain connections
            if hasattr(workbook, 'defined_names'):
                for name in workbook.defined_names.definedName:
                    if re.search(r'(ODBC|CONNECTION|DSN|SERVER|DATABASE)', name.value, re.IGNORECASE):
                        conn_info = {
                            'connection_type': 'Defined Name',
                            'connection_string': name.value,
                            'target_resource': self._extract_target_from_connection(name.value),
                            'sensitivity_level': self._assess_connection_sensitivity(name.value)
                        }
                        self.connections.append(conn_info)
                        
            # Close workbook
            workbook.close()
            
        except Exception as e:
            logger.error(f"Error in openpyxl connection analysis: {e}")
            
    def _analyze_connection_patterns(self):
        """Look for connection patterns in the raw file content."""
        try:
            # Read file content
            with open(self.file_path, 'rb') as file:
                content = file.read().decode('latin-1', errors='ignore')
                
            # Look for common connection patterns
            connection_patterns = [
                (r'(?:Provider=([^;]+);)?(?:Data Source|Server|DSN)=([^;]+);', 'ODBC/OLE DB'),
                (r'(?:jdbc:[a-z]+://[^;"\s]+)', 'JDBC'),
                (r'(?:Data Source|Server)=([^;"\s]+)', 'SQL Connection'),
                (r'(?:Database=([^;"\s]+))', 'Database Connection'),
                (r'(?:http[s]?://[^\s"\']+)', 'Web Connection'),
                (r'(?:ftp://[^\s"\']+)', 'FTP Connection')
            ]
            
            for pattern, conn_type in connection_patterns:
                matches = re.findall(pattern, content)
                
                for match in matches:
                    target = match[1] if isinstance(match, tuple) and len(match) > 1 else match
                    
                    # Check if this connection is already in our list
                    if not any(conn['target_resource'] == target for conn in self.connections):
                        conn_info = {
                            'connection_type': conn_type,
                            'connection_string': str(match),
                            'target_resource': target,
                            'sensitivity_level': self._assess_connection_sensitivity(str(match))
                        }
                        self.connections.append(conn_info)
                        
        except Exception as e:
            logger.error(f"Error in connection pattern analysis: {e}")
            
    def _extract_target_from_connection(self, connection_string):
        """Extract the target resource from a connection string."""
        if not connection_string:
            return "Unknown"
            
        # Try to find server or data source
        server_match = re.search(r'(?:Server|Data Source|DSN)=([^;]+)', connection_string)
        if server_match:
            return server_match.group(1).strip()
            
        # Try to find database
        db_match = re.search(r'(?:Database|Initial Catalog)=([^;]+)', connection_string)
        if db_match:
            return db_match.group(1).strip()
            
        # Try to find URL
        url_match = re.search(r'(https?://[^\s;]+)', connection_string)
        if url_match:
            return url_match.group(1).strip()
            
        # If nothing specific found
        return connection_string[:50] + ('...' if len(connection_string) > 50 else '')
        
    def _extract_target_from_link(self, link):
        """Extract the target resource from an external link."""
        if hasattr(link, 'file_link'):
            return link.file_link.target
            
        return str(link)
        
    def _assess_connection_sensitivity(self, connection_string):
        """Assess the sensitivity level of a connection."""
        if not connection_string:
            return "low"
            
        # Define sensitivity indicators
        high_sensitivity = [
            'prod', 'production', 'customer', 'client', 'employee', 'personal', 
            'financial', 'finance', 'salary', 'private', 'secure', 'confidential',
            'ssn', 'social security'
        ]
        
        medium_sensitivity = [
            'sales', 'marketing', 'dev', 'development', 'test', 'internal',
            'analytics', 'report', 'data', 'metadata'
        ]
        
        # Check for high sensitivity
        for term in high_sensitivity:
            if re.search(r'\b' + re.escape(term) + r'\b', connection_string, re.IGNORECASE):
                return "high"
                
        # Check for medium sensitivity
        for term in medium_sensitivity:
            if re.search(r'\b' + re.escape(term) + r'\b', connection_string, re.IGNORECASE):
                return "medium"
                
        # Default to low
        return "low"
