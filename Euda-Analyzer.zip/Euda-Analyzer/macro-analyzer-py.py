import os
import logging
import re
try:
    import win32com.client
    HAS_WIN32COM = True
except ImportError:
    HAS_WIN32COM = False

logger = logging.getLogger(__name__)

class MacroAnalyzer:
    """Class for analyzing Excel macros (VBA code)."""
    
    def __init__(self, file_path):
        """Initialize with the path to an Excel file."""
        self.file_path = file_path
        self.excel_app = None
        self.macros = []
        
    def analyze(self):
        """Analyze the macros in the Excel file."""
        if not self._is_macro_file():
            logger.info(f"File does not appear to contain macros: {self.file_path}")
            return []
            
        if not HAS_WIN32COM:
            logger.warning("win32com not available. Limited macro analysis available.")
            return self._analyze_without_win32com()
            
        try:
            return self._analyze_with_win32com()
        except Exception as e:
            logger.error(f"Error analyzing macros with win32com: {e}")
            return self._analyze_without_win32com()
            
    def _is_macro_file(self):
        """Check if the file is likely to contain macros based on extension."""
        ext = os.path.splitext(self.file_path)[1].lower()
        return ext in ['.xlsm', '.xls', '.xlm']
        
    def _analyze_with_win32com(self):
        """Analyze macros using win32com (Windows only)."""
        try:
            # Initialize Excel application
            self.excel_app = win32com.client.Dispatch("Excel.Application")
            self.excel_app.Visible = False
            self.excel_app.DisplayAlerts = False
            
            # Open the workbook
            workbook = self.excel_app.Workbooks.Open(self.file_path)
            
            # Get VBA project
            vba_project = workbook.VBProject
            
            # Loop through all VBA components
            for component in vba_project.VBComponents:
                macro_info = {
                    'macro_name': component.Name,
                    'macro_type': self._get_component_type(component.Type),
                    'macro_code': component.CodeModule.Lines(1, component.CodeModule.CountOfLines),
                    'macro_purpose': self._infer_macro_purpose(component.CodeModule.Lines(1, component.CodeModule.CountOfLines)),
                    'complexity_score': self._calculate_macro_complexity(component.CodeModule.Lines(1, component.CodeModule.CountOfLines)),
                    'risk_score': self._assess_macro_risk(component.CodeModule.Lines(1, component.CodeModule.CountOfLines))
                }
                self.macros.append(macro_info)
                
            # Close workbook and quit Excel
            workbook.Close(SaveChanges=False)
            self.excel_app.Quit()
            
            logger.info(f"Analyzed {len(self.macros)} macros in {self.file_path}")
            return self.macros
        except Exception as e:
            logger.error(f"Error in win32com macro analysis: {e}")
            if self.excel_app:
                try:
                    self.excel_app.Quit()
                except:
                    pass
            raise
            
    def _analyze_without_win32com(self):
        """Fallback method when win32com is not available."""
        logger.info("Using fallback macro analysis without win32com")
        
        try:
            # Try to extract macros by directly reading the file as binary and looking for patterns
            with open(self.file_path, 'rb') as file:
                content = file.read().decode('latin-1')  # Use latin-1 to handle binary content
                
                # Look for VBA module patterns
                modules = re.findall(r'Attribute VB_Name = "([^"]+)"', content)
                
                for module_name in modules:
                    # Create basic info for each identified module
                    macro_info = {
                        'macro_name': module_name,
                        'macro_type': 'Unknown',
                        'macro_code': 'Code extraction not available without win32com',
                        'macro_purpose': 'Unknown (limited analysis)',
                        'complexity_score': 0.5,  # Default medium complexity
                        'risk_score': 0.7  # Higher risk score due to limited analysis
                    }
                    self.macros.append(macro_info)
                    
            logger.info(f"Identified {len(self.macros)} potential macros in {self.file_path} (limited analysis)")
            return self.macros
        except Exception as e:
            logger.error(f"Error in fallback macro analysis: {e}")
            return []
            
    def _get_component_type(self, type_num):
        """Convert VBA component type number to string representation."""
        types = {
            1: "Standard Module",
            2: "Class Module",
            3: "UserForm",
            100: "Document Module"
        }
        return types.get(type_num, "Unknown")
        
    def _infer_macro_purpose(self, code):
        """Attempt to infer the purpose of the macro from its code."""
        purpose_keywords = {
            'data import': ['import', 'read', 'load', 'get data', 'connection', 'adodb', 'recordset'],
            'data export': ['export', 'save', 'write', 'output'],
            'data processing': ['calculate', 'process', 'transform', 'format'],
            'ui automation': ['msgbox', 'userform', 'input', 'button', 'click'],
            'reporting': ['report', 'print', 'summary', 'chart'],
            'database': ['sql', 'query', 'database', 'table', 'select', 'insert', 'update'],
            'file operations': ['file', 'folder', 'directory', 'path', 'open', 'close']
        }
        
        # Convert code to lowercase for case-insensitive matching
        code_lower = code.lower()
        
        # Count occurrences of each purpose's keywords
        purpose_scores = {}
        for purpose, keywords in purpose_keywords.items():
            purpose_scores[purpose] = sum(code_lower.count(keyword.lower()) for keyword in keywords)
            
        # Get the purpose with the highest score
        if purpose_scores:
            max_purpose = max(purpose_scores.items(), key=lambda x: x[1])
            if max_purpose[1] > 0:
                return max_purpose[0].title()
                
        # If no clear purpose is found
        return "General Automation"
        
    def _calculate_macro_complexity(self, code):
        """Calculate a complexity score for the macro code."""
        # Basic complexity indicators
        indicators = {
            'length': len(code),
            'loop_count': code.lower().count('for ') + code.lower().count('do while') + code.lower().count('do until'),
            'if_count': code.lower().count('if '),
            'function_count': code.lower().count('function ') + code.lower().count('sub '),
            'api_calls': code.lower().count('declare '),
            'sql_queries': code.lower().count('select ') + code.lower().count('insert ') + code.lower().count('update ')
        }
        
        # Calculate weighted score (0-1 scale)
        max_length = 10000  # Consider any code over 10K chars as very complex
        length_score = min(1.0, indicators['length'] / max_length)
        
        control_flow_score = min(1.0, (
            indicators['loop_count'] * 0.1 + 
            indicators['if_count'] * 0.05 + 
            indicators['function_count'] * 0.15 + 
            indicators['api_calls'] * 0.3 + 
            indicators['sql_queries'] * 0.2
        ))
        
        # Combined score (0-1 scale)
        complexity_score = 0.4 * length_score + 0.6 * control_flow_score
        return complexity_score
        
    def _assess_macro_risk(self, code):
        """Assess potential risk level of the macro code."""
        # Risk indicators
        risk_patterns = {
            'high': [
                r'shell\s*\(', r'createobject\s*\(\s*["\']wscript', r'filesystemobject',
                r'adodb\.connection', r'executable', r'kill\s+', r'delete\s+',
                r'system32', r'cmd\.exe', r'powershell', r'hidden'
            ],
            'medium': [
                r'http', r'url', r'ftp', r'activexobject', r'sendkeys', 
                r'application\.run', r'execute', r'sql', r'password', r'credentials'
            ],
            'low': [
                r'msgbox', r'range', r'worksheet', r'cell', r'format', r'color',
                r'font', r'border', r'inputbox'
            ]
        }
        
        code_lower = code.lower()
        
        # Count occurrences of each risk level patterns
        risk_counts = {level: 0 for level in risk_patterns}
        
        for level, patterns in risk_patterns.items():
            for pattern in patterns:
                matches = len(re.findall(pattern, code_lower))
                risk_counts[level] += matches
                
        # Calculate weighted risk score (0-1 scale)
        risk_score = (
            risk_counts['high'] * 0.7 + 
            risk_counts['medium'] * 0.3 + 
            risk_counts['low'] * 0.1
        ) / 10  # Normalize 
        
        return min(1.0, max(0.1, risk_score))  # Ensure between 0.1 and 1.0
