#!/usr/bin/env python3
"""
Entry point for EUDA Analyzer web application.
This script runs a Flask web application for analyzing Excel EUDAs and querying results.
"""

import os
import argparse
import logging
from api_service import APIService

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("euda_analyzer_app.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='Run EUDA Analyzer web application')
    parser.add_argument(
        '--host', 
        type=str, 
        default='0.0.0.0',
        help='Host to bind the server to'
    )
    parser.add_argument(
        '--port', 
        type=int, 
        default=5000,
        help='Port to bind the server to'
    )
    parser.add_argument(
        '--debug', 
        action='store_true',
        help='Run in debug mode'
    )
    parser.add_argument(
        '--config', '-c',
        type=str, 
        default='config.ini',
        help='Path to configuration file'
    )
    return parser.parse_args()

def main():
    """Main function to run the EUDA Analyzer web application."""
    args = parse_arguments()
    
    try:
        # Create and run API service
        api_service = APIService(config_path=args.config)
        logger.info(f"Starting EUDA Analyzer web application on {args.host}:{args.port}")
        api_service.run(host=args.host, port=args.port, debug=args.debug)
        return 0
    
    except Exception as e:
        logger.error(f"Error running EUDA Analyzer web application: {str(e)}", exc_info=True)
        return 1

if __name__ == "__main__":
    exit_code = main()
    exit(exit_code)
