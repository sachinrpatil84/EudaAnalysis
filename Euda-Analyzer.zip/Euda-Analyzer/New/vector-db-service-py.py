#!/usr/bin/env python3
"""
Service for interacting with PostgreSQL vector database.
Handles storing and retrieving EUDA analysis results.
"""

import json
import logging
from typing import Dict, Any, List, Tuple, Optional
import psycopg2
from psycopg2.extras import Json, execute_values

from db_connector import DBConnector
from schema import create_tables_query

logger = logging.getLogger(__name__)

class VectorDBService:
    """
    Service for managing EUDA data in PostgreSQL vector database.
    """
    
    def __init__(self, db_connector: DBConnector):
        """
        Initialize the vector database service.
        
        Args:
            db_connector: Database connector instance for PostgreSQL connection
        """
        self.db_connector = db_connector
        
        # Ensure tables exist
        self._initialize_database()
        
        logger.info("Initialized VectorDBService")
    
    def _initialize_database(self):
        """Initialize the database with required tables and extensions."""
        try:
            conn = self.db_connector.get_connection()
            with conn.cursor() as cursor:
                # Enable the pgvector extension if not already enabled
                cursor.execute("CREATE EXTENSION IF NOT EXISTS vector;")
                
                # Create tables
                cursor.execute(create_tables_query)
                
            conn.commit()
            logger.info("Database schema initialized successfully")
        except Exception as e:
            logger.error(f"Error initializing database schema: {str(e)}")
            raise
        finally:
            if conn:
                conn.close()
    
    def store_euda_analysis(self, euda_analysis: Dict[str, Any]) -> int:
        """
        Store EUDA analysis results in the database.
        
        Args:
            euda_analysis: Dictionary containing EUDA analysis results
            
        Returns:
            The ID of the stored EUDA record
        """
        try:
            conn = self.db_connector.get_connection()
            euda_id = None
            
            with conn.cursor() as cursor:
                # First, insert the basic EUDA information
                cursor.execute(
                    """
                    INSERT INTO eudas (
                        filename, 
                        description, 
                        complexity_score, 
                        risk_score,
                        data_sensitivity,
                        compliance_status,
                        created_at, 
                        updated_at
                    ) VALUES (%s, %s, %s, %s, %s, %s, NOW(), NOW())
                    RETURNING id
                    """,
                    (
                        euda_analysis.get('filename', ''),
                        euda_analysis.get('description', ''),
                        euda_analysis.get('complexity_score', 0.0),
                        euda_analysis.get('risk_score', 0.0),
                        euda_analysis.get('data_sensitivity', 'UNKNOWN'),
                        json.dumps(euda_analysis.get('compliance_status', {})),
                    )
                )
                euda_id = cursor.fetchone()[0]
                
                # Store embeddings
                if 'embeddings' in euda_analysis:
                    for embedding_type, embedding_vector in euda_analysis['embeddings'].items():
                        cursor.execute(
                            """
                            INSERT INTO euda_embeddings (
                                euda_id,
                                embedding_type,
                                embedding_vector,
                                created_at
                            ) VALUES (%s, %s, %s, NOW())
                            """,
                            (
                                euda_id,
                                embedding_type,
                                embedding_vector
                            )
                        )
                
                # Store formulas
                if 'formulas' in euda_analysis:
                    formula_values = [
                        (
                            euda_id,
                            formula.get('sheet_name', ''),
                            formula.get('cell_reference', ''),
                            formula.get('formula_text', ''),
                            formula.get('complexity', 0.0)
                        )
                        for formula in euda_analysis.get('formulas', [])
                    ]
                    
                    execute_values(
                        cursor,
                        """
                        INSERT INTO euda_formulas (
                            euda_id,
                            sheet_name,
                            cell_reference,
                            formula_text,
                            complexity
                        ) VALUES %s
                        """,
                        formula_values
                    )
                
                # Store macros
                if 'macros' in euda_analysis:
                    macro_values = [
                        (
                            euda_id,
                            macro.get('name', ''),
                            macro.get('code', ''),
                            macro.get('complexity', 0.0),
                            macro.get('risk_level', 'UNKNOWN')
                        )
                        for macro in euda_analysis.get('macros', [])
                    ]
                    
                    execute_values(
                        cursor,
                        """
                        INSERT INTO euda_macros (
                            euda_id,
                            macro_name,
                            macro_code,
                            complexity,
                            risk_level
                        ) VALUES %s
                        """,
                        macro_values
                    )
                
                # Store connections
                if 'connections' in euda_analysis:
                    connection_values = [
                        (
                            euda_id,
                            connection.get('type', ''),
                            connection.get('target', ''),
                            connection.get('is_sensitive', False)
                        )
                        for connection in euda_analysis.get('connections', [])
                    ]
                    
                    execute_values(
                        cursor,
                        """
                        INSERT INTO euda_connections (
                            euda_id,
                            connection_type,
                            connection_target,
                            is_sensitive
                        ) VALUES %s
                        """,
                        connection_values
                    )
                
                # Store sheets
                if 'sheets' in euda_analysis:
                    sheet_values = [
                        (
                            euda_id,
                            sheet_name
                        )
                        for sheet_name in euda_analysis.get('sheets', [])
                    ]
                    
                    execute_values(
                        cursor,
                        """
                        INSERT INTO euda_sheets (
                            euda_id,
                            sheet_name
                        ) VALUES %s
                        """,
                        sheet_values
                    )
            
            conn.commit()
            logger.info(f"Stored EUDA analysis with ID {euda_id}")
            return euda_id
            
        except Exception as e:
            if conn:
                conn.rollback()
            logger.error(f"Error storing EUDA analysis: {str(e)}")
            raise
        finally:
            if conn:
                conn.close()
    
    def find_similar_eudas(self, 
                          query_embedding: List[float], 
                          limit: int = 10, 
                          threshold: float = 0.7) -> List[Dict[str, Any]]:
        """
        Find similar EUDAs based on vector similarity.
        
        Args:
            query_embedding: The query embedding vector
            limit: Maximum number of results to return
            threshold: Similarity threshold (0-1)
            
        Returns:
            List of similar EUDA records with similarity scores
        """
        try:
            conn = self.db_connector.get_connection()
            
            with conn.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT 
                        e.id,
                        e.filename,
                        e.description,
                        e.complexity_score,
                        e.risk_score,
                        e.data_sensitivity,
                        1 - (ee.embedding_vector <=> %s) as similarity
                    FROM 
                        eudas e
                    JOIN 
                        euda_embeddings ee ON e.id = ee.euda_id
                    WHERE 
                        ee.embedding_type = 'overall'
                        AND 1 - (ee.embedding_vector <=> %s) > %s
                    ORDER BY 
                        similarity DESC
                    LIMIT %s
                    """,
                    (query_embedding, query_embedding, threshold, limit)
                )
                
                results = []
                for row in cursor.fetchall():
                    results.append({
                        'id': row[0],
                        'filename': row[1],
                        'description': row[2],
                        'complexity_score': row[3],
                        'risk_score': row[4],
                        'data_sensitivity': row[5],
                        'similarity': row[6]
                    })
                
                return results
                
        except Exception as e:
            logger.error(f"Error finding similar EUDAs: {str(e)}")
            raise
        finally:
            if conn:
                conn.close()
    
    def get_euda_by_id(self, euda_id: int) -> Dict[str, Any]:
        """
        Retrieve complete EUDA information by ID.
        
        Args:
            euda_id: The ID of the EUDA to retrieve
            
        Returns:
            Dictionary containing complete EUDA information
        """
        try:
            conn = self.db_connector.get_connection()
            
            result = {}
            
            with conn.cursor() as cursor:
                # Get basic EUDA info
                cursor.execute(
                    """
                    SELECT 
                        id, 
                        filename, 
                        description, 
                        complexity_score, 
                        risk_score,
                        data_sensitivity,
                        compliance_status
                    FROM 
                        eudas
                    WHERE 
                        id = %s
                    """,
                    (euda_id,)
                )
                
                row = cursor.fetchone()
                if not row:
                    return None
                
                result = {
                    'id': row[0],
                    'filename': row[1],
                    'description': row[2],
                    'complexity_score': row[3],
                    'risk_score': row[4],
                    'data_sensitivity': row[5],
                    'compliance_status': json.loads(row[6]) if row[6] else {}
                }
                
                # Get formulas
                cursor.execute(
                    """
                    SELECT 
                        sheet_name,
                        cell_reference,
                        formula_text,
                        complexity
                    FROM 
                        euda_formulas
                    WHERE 
                        euda_id = %s
                    """,
                    (euda_id,)
                )
                
                result['formulas'] = []
                for formula_row in cursor.fetchall():
                    result['formulas'].append({
                        'sheet_name': formula_row[0],
                        'cell_reference': formula_row[1],
                        'formula_text': formula_row[2],
                        'complexity': formula_row[3]
                    })
                
                # Get macros
                cursor.execute(
                    """
                    SELECT 
                        macro_name,
                        macro_code,
                        complexity,
                        risk_level
                    FROM 
                        euda_macros
                    WHERE 
                        euda_id = %s
                    """,
                    (euda_id,)
                )
                
                result['macros'] = []
                for macro_row in cursor.fetchall():
                    result['macros'].append({
                        'name': macro_row[0],
                        'code': macro_row[1],
                        'complexity': macro_row[2],
                        'risk_level': macro_row[3]
                    })
                
                # Get connections
                cursor.execute(
                    """
                    SELECT 
                        connection_type,
                        connection_target,
                        is_sensitive
                    FROM 
                        euda_connections
                    WHERE 
                        euda_id = %s
                    """,
                    (euda_id,)
                )
                
                result['connections'] = []
                for conn_row in cursor.fetchall():
                    result['connections'].append({
                        'type': conn_row[0],
                        'target': conn_row[1],
                        'is_sensitive': conn_row[2]
                    })
                
                # Get sheets
                cursor.execute(
                    """
                    SELECT 
                        sheet_name
                    FROM 
                        euda_sheets
                    WHERE 
                        euda_id = %s
                    """,
                    (euda_id,)
                )
                
                result['sheets'] = [row[0] for row in cursor.fetchall()]
                
            return result
                
        except Exception as e:
            logger.error(f"Error retrieving EUDA by ID: {str(e)}")
            raise
        finally:
            if conn:
                conn.close()
    
    def get_all_eudas(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Retrieve a list of all EUDAs with basic information.
        
        Args:
            limit: Maximum number of records to return
            offset: Number of records to skip
            
        Returns:
            List of EUDA records
        """
        try:
            conn = self.db_connector.get_connection()
            
            with conn.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT 
                        id, 
                        filename, 
                        description, 
                        complexity_score, 
                        risk_score,
                        data_sensitivity
                    FROM 
                        eudas
                    ORDER BY 
                        id DESC
                    LIMIT %s OFFSET %s
                    """,
                    (limit, offset)
                )
                
                results = []
                for row in cursor.fetchall():
                    results.append({
                        'id': row[0],
                        'filename': row[1],
                        'description': row[2],
                        'complexity_score': row[3],
                        'risk_score': row[4],
                        'data_sensitivity': row[5]
                    })
                
                return results
                
        except Exception as e:
            logger.error(f"Error retrieving all EUDAs: {str(e)}")
            raise
        finally:
            if conn:
                conn.close()
