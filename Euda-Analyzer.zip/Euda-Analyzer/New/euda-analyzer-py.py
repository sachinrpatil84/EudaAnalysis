#!/usr/bin/env python3
"""
Core EUDA analyzer class that orchestrates the analysis process.
"""

import os
import logging
from typing import Dict, Any, List, Optional
import json

from excel_parser import ExcelParser
from complexity_calculator import ComplexityCalculator
from risk_assessor import RiskAssessor
from formula_analyzer import FormulaAnalyzer
from macro_analyzer import MacroAnalyzer
from connection_analyzer import ConnectionAnalyzer
from embedding_service import EmbeddingService
from vector_db_service import VectorDBService
from utils import generate_euda_description

logger = logging.getLogger(__name__)

class EUDAAnalyzer:
    """
    Main class for analyzing Excel EUDA files and storing their characteristics
    in a vector database.
    """
    
    def __init__(
        self,
        embedding_service: EmbeddingService,
        vector_db_service: VectorDBService
    ):
        """
        Initialize the EUDA analyzer.
        
        Args:
            embedding_service: Service for generating embeddings
            vector_db_service: Service for storing analysis in vector DB
        """
        self.excel_parser = ExcelParser()
        self.complexity_calculator = ComplexityCalculator()
        self.risk_assessor = RiskAssessor()
        self.formula_analyzer = FormulaAnalyzer()
        self.macro_analyzer = MacroAnalyzer()
        self.connection_analyzer = ConnectionAnalyzer()
        self.embedding_service = embedding_service
        self.vector_db_service = vector_db_service
        
        logger.info("Initialized EUDAAnalyzer")
    
    def analyze(self, file_path: str) -> Dict[str, Any]:
        """
        Perform comprehensive analysis of an Excel EUDA file.
        
        Args:
            file_path: Path to the Excel file to analyze
            
        Returns:
            Dictionary containing analysis results
        """
        try:
            logger.info(f"Starting analysis of {file_path}")
            
            # Parse the Excel file
            excel_data = self.excel_parser.parse(file_path)
            filename = os.path.basename(file_path)
            excel_data['filename'] = filename
            
            # Analyze formulas
            formulas = self.formula_analyzer.analyze(excel_data)
            excel_data['formulas'] = formulas
            
            # Analyze macros
            macros = self.macro_analyzer.analyze(excel_data)
            excel_data['macros'] = macros
            
            # Analyze connections
            connections = self.connection_analyzer.analyze(excel_data)
            excel_data['connections'] = connections
            
            # Calculate complexity score
            complexity_score = self.complexity_calculator.calculate(
                excel_data, 
                formulas=formulas, 
                macros=macros,
                connections=connections
            )
            excel_data['complexity_score'] = complexity_score
            
            # Assess risk and data sensitivity
            risk_assessment = self.risk_assessor.assess(
                excel_data,
                formulas=formulas,
                macros=macros,
                connections=connections
            )
            excel_data['risk_score'] = risk_assessment['risk_score']
            excel_data['data_sensitivity'] = risk_assessment['data_sensitivity']
            excel_data['compliance_status'] = risk_assessment['compliance_status']
            
            # Generate a descriptive summary of the EUDA
            excel_data['description'] = generate_euda_description(excel_data)
            
            # Generate embeddings
            excel_data['embeddings'] = self.embedding_service.generate_excel_embedding(excel_data)
            
            # Store in vector database
            euda_id = self.vector_db_service.store_euda_analysis(excel_data)
            excel_data['id'] = euda_id
            
            logger.info(f"Completed analysis of {file_path}, assigned ID: {euda_id}")
            
            return excel_data
            
        except Exception as e:
            logger.error(f"Error analyzing {file_path}: {str(e)}")
            raise
    
    def search_similar_eudas(self, query_text: str, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Search for similar EUDAs based on text query.
        
        Args:
            query_text: Text query to search for
            limit: Maximum number of results to return
            
        Returns:
            List of similar EUDA records
        """
        try:
            # Generate embedding for the query text
            query_embedding = self.embedding_service.generate_text_embedding(query_text)
            
            # Search in vector database
            similar_eudas = self.vector_db_service.find_similar_eudas(
                query_embedding,
                limit=limit
            )
            
            return similar_eudas
            
        except Exception as e:
            logger.error(f"Error searching for similar EUDAs: {str(e)}")
            raise
    
    def get_euda_by_id(self, euda_id: int) -> Dict[str, Any]:
        """
        Retrieve complete EUDA information by ID.
        
        Args:
            euda_id: The ID of the EUDA to retrieve
            
        Returns:
            Dictionary containing complete EUDA information
        """
        return self.vector_db_service.get_euda_by_id(euda_id)
    
    def get_all_eudas(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Retrieve a list of all EUDAs with basic information.
        
        Args:
            limit: Maximum number of records to return
            offset: Number of records to skip
            
        Returns:
            List of EUDA records
        """
        return self.vector_db_service.get_all_eudas(limit, offset)
