#!/usr/bin/env python3
"""
Service for generating embeddings using Amazon Titan models.
"""

import json
import logging
import boto3
from typing import Dict, Any, List, Union, Optional
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

class EmbeddingService:
    """
    Service for generating embeddings using Amazon Titan models.
    Supports both text and image embeddings.
    """
    
    def __init__(
        self, 
        model_id: str, 
        region_name: str, 
        aws_access_key_id: Optional[str] = None, 
        aws_secret_access_key: Optional[str] = None
    ):
        """
        Initialize the embedding service.
        
        Args:
            model_id: The Amazon Titan model ID to use for embeddings
            region_name: AWS region where the model is deployed
            aws_access_key_id: AWS access key ID (optional if using instance profile)
            aws_secret_access_key: AWS secret access key (optional if using instance profile)
        """
        self.model_id = model_id
        self.region_name = region_name
        
        # Initialize AWS session
        session_kwargs = {
            'region_name': region_name
        }
        
        if aws_access_key_id and aws_secret_access_key:
            session_kwargs.update({
                'aws_access_key_id': aws_access_key_id,
                'aws_secret_access_key': aws_secret_access_key
            })
        
        self.session = boto3.Session(**session_kwargs)
        self.bedrock_runtime = self.session.client(
            service_name='bedrock-runtime'
        )
        
        logger.info(f"Initialized EmbeddingService with model {model_id} in region {region_name}")
        
    def generate_text_embedding(self, text: str) -> List[float]:
        """
        Generate embeddings for the given text using Amazon Titan.
        
        Args:
            text: The text to generate embeddings for
            
        Returns:
            A list of float values representing the embedding vector
        """
        if not text:
            logger.warning("Empty text provided for embedding generation")
            return []
        
        try:
            request_body = json.dumps({
                "inputText": text
            })
            
            response = self.bedrock_runtime.invoke_model(
                modelId=self.model_id,
                contentType="application/json",
                accept="application/json",
                body=request_body
            )
            
            response_body = json.loads(response.get("body").read())
            embedding = response_body.get("embedding", [])
            
            logger.debug(f"Generated embedding of dimension {len(embedding)}")
            return embedding
            
        except ClientError as e:
            logger.error(f"AWS Bedrock API error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error generating text embedding: {str(e)}")
            raise
    
    def generate_batch_embeddings(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple texts.
        
        Args:
            texts: List of texts to generate embeddings for
            
        Returns:
            List of embedding vectors
        """
        embeddings = []
        
        for i, text in enumerate(texts):
            try:
                embedding = self.generate_text_embedding(text)
                embeddings.append(embedding)
                logger.debug(f"Generated embedding {i+1}/{len(texts)}")
            except Exception as e:
                logger.error(f"Failed to generate embedding for text {i+1}: {str(e)}")
                embeddings.append([])
                
        return embeddings
    
    def generate_excel_embedding(self, 
                                excel_data: Dict[str, Any], 
                                include_formulas: bool = True,
                                include_macros: bool = True,
                                include_connections: bool = True) -> Dict[str, List[float]]:
        """
        Generate embeddings for different components of an Excel file.
        
        Args:
            excel_data: Dictionary containing parsed Excel data
            include_formulas: Whether to include formula text in the embedding
            include_macros: Whether to include macro code in the embedding
            include_connections: Whether to include connection details in the embedding
            
        Returns:
            Dictionary mapping component names to their embedding vectors
        """
        embeddings = {}
        
        # Generate embedding for the overall description and content
        overall_text = f"Excel file: {excel_data.get('filename', '')}\n"
        overall_text += f"Description: {excel_data.get('description', '')}\n"
        overall_text += f"Sheets: {', '.join(excel_data.get('sheets', []))}\n"
        
        embeddings['overall'] = self.generate_text_embedding(overall_text)
        
        # Generate embeddings for formulas if requested
        if include_formulas and 'formulas' in excel_data:
            formula_text = json.dumps(excel_data['formulas'])
            embeddings['formulas'] = self.generate_text_embedding(formula_text)
        
        # Generate embeddings for macros if requested
        if include_macros and 'macros' in excel_data:
            macro_text = json.dumps(excel_data['macros'])
            embeddings['macros'] = self.generate_text_embedding(macro_text)
        
        # Generate embeddings for connections if requested
        if include_connections and 'connections' in excel_data:
            connection_text = json.dumps(excel_data['connections'])
            embeddings['connections'] = self.generate_text_embedding(connection_text)
        
        return embeddings
