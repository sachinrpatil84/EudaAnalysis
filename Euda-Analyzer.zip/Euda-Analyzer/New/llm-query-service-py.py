#!/usr/bin/env python3
"""
Service for using LLMs to query and interact with EUDA analysis results.
"""

import json
import logging
import boto3
import time
from typing import Dict, Any, List, Optional
from botocore.exceptions import ClientError
from string import Template

from vector_db_service import VectorDBService
from embedding_service import EmbeddingService

logger = logging.getLogger(__name__)

class LLMQueryService:
    """
    Service for using LLMs to query and interact with EUDA analysis results.
    """
    
    def __init__(
        self, 
        vector_db_service: VectorDBService,
        embedding_service: EmbeddingService,
        llm_model_id: str = "amazon.titan-text-express-v1",
        region_name: str = "us-east-1",
        aws_access_key_id: Optional[str] = None,
        aws_secret_access_key: Optional[str] = None,
        max_tokens: int = 1024,
        temperature: float = 0.7
    ):
        """
        Initialize the LLM query service.
        
        Args:
            vector_db_service: Service for interacting with vector database
            embedding_service: Service for generating embeddings
            llm_model_id: AWS Bedrock model ID for LLM
            region_name: AWS region where the model is deployed
            aws_access_key_id: AWS access key ID (optional if using instance profile)
            aws_secret_access_key: AWS secret access key (optional if using instance profile)
            max_tokens: Maximum number of tokens to generate
            temperature: Temperature for text generation
        """
        self.vector_db_service = vector_db_service
        self.embedding_service = embedding_service
        self.model_id = llm_model_id
        self.max_tokens = max_tokens
        self.temperature = temperature
        
        # Initialize AWS session
        session_kwargs = {
            'region_name': region_name
        }
        
        if aws_access_key_id and aws_secret_access_key:
            session_kwargs.update({
                'aws_access_key_id': aws_access_key_id,
                'aws_secret_access_key': aws_secret_access_key
            })
        
        self.session = boto3.Session(**session_kwargs)
        self.bedrock_runtime = self.session.client(
            service_name='bedrock-runtime'
        )
        
        logger.info(f"Initialized LLMQueryService with model {llm_model_id}")
        
        # Templates for different query types
        self.prompt_templates = {
            'general_query': Template("""
You are an assistant that helps users understand Excel End User Developed Applications (EUDAs).
Below are details about an EUDA that the user is asking about. Please provide a helpful, accurate
and concise response to their query.

EUDA INFORMATION:
$euda_info

USER QUERY:
$query

Your response should be:
1. Relevant to the specific query 
2. Based only on the information provided
3. Professional and concise
4. Include specific details from the EUDA information where appropriate
            """),
            
            'remediation_advice': Template("""
You are an expert consultant who specializes in EUDA remediation and governance. 
Your task is to provide advice on how to remediate or improve the EUDA described below.

EUDA INFORMATION:
$euda_info

USER QUERY ABOUT REMEDIATION:
$query

Your response should:
1. Identify specific issues in the EUDA that need remediation based on the information provided
2. Suggest practical steps to improve the EUDA
3. Consider complexity, risk, data sensitivity, and compliance issues
4. Provide recommendations in order of priority
5. Be concise and actionable
            """),
            
            'compliance_check': Template("""
You are a compliance expert specialized in Excel End User Developed Applications (EUDAs).
Based on the information provided about the EUDA below, assess its compliance status and risks.

EUDA INFORMATION:
$euda_info

COMPLIANCE QUERY:
$query

Your response should:
1. Identify specific compliance concerns or risks in the EUDA
2. Reference specific elements from the EUDA information that present compliance issues
3. Provide a clear assessment of compliance status
4. Suggest remediation steps for any compliance gaps identified
5. Be concise and professional
            """),
            
            'complexity_explanation': Template("""
You are an expert in Excel applications analyzing the complexity of an End User Developed Application (EUDA).
Based on the information provided about the EUDA below, explain its complexity aspects.

EUDA INFORMATION:
$euda_info

COMPLEXITY QUERY:
$query

Your response should:
1. Identify the key factors contributing to the complexity of this EUDA
2. Explain technical aspects in simple, understandable terms
3. Highlight specific complex elements (formulas, macros, connections)
4. Assess whether the complexity is necessary or could be reduced
5. Be concise and informative
            """)
        }
    
    def query_llm(self, prompt: str) -> str:
        """
        Send a query to the LLM and get a response.
        
        Args:
            prompt: The prompt to send to the LLM
            
        Returns:
            The LLM's response as a string
        """
        try:
            request_body = json.dumps({
                "inputText": prompt,
                "textGenerationConfig": {
                    "maxTokenCount": self.max_tokens,
                    "temperature": self.temperature,
                    "topP": 0.9
                }
            })
            
            response = self.bedrock_runtime.invoke_model(
                modelId=self.model_id,
                contentType="application/json",
                accept="application/json",
                body=request_body
            )
            
            response_body = json.loads(response.get("body").read())
            generated_text = response_body.get("results", [{}])[0].get("outputText", "")
            
            return generated_text
            
        except ClientError as e:
            logger.error(f"AWS Bedrock API error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error querying LLM: {str(e)}")
            raise
    
    def _format_euda_info(self, euda_data: Dict[str, Any]) -> str:
        """
        Format EUDA data for inclusion in a prompt.
        
        Args:
            euda_data: Dictionary containing EUDA data
            
        Returns:
            Formatted string with EUDA information
        """
        info = f"EUDA ID: {euda_data.get('id')}\n"
        info += f"Filename: {euda_data.get('filename', 'Unknown')}\n"
        info += f"Description: {euda_data.get('description', 'No description available')}\n\n"
        
        info += f"Complexity Score: {euda_data.get('complexity_score', 0)}/10\n"
        info += f"Risk Score: {euda_data.get('risk_score', 0)}/10\n"
        info += f"Data Sensitivity: {euda_data.get('data_sensitivity', 'UNKNOWN')}\n\n"
        
        # Add compliance information
        compliance_status = euda_data.get('compliance_status', {})
        if compliance_status:
            info += "Compliance Status:\n"
            for standard, status in compliance_status.items():
                info += f"- {standard}: {status}\n"
            info += "\n"
        
        # Add formula information
        formulas = euda_data.get('formulas', [])
        if formulas:
            info += f"Contains {len(formulas)} formulas. "
            complex_formulas = [f for f in formulas if f.get('complexity', 0) > 5]
            if complex_formulas:
                info += f"There are {len(complex_formulas)} complex formulas.\n"
                for i, formula in enumerate(complex_formulas[:3]):
                    sheet = formula.get('sheet_name', 'Unknown')
                    cell = formula.get('cell_reference', 'Unknown')
                    complexity = formula.get('complexity', 0)
                    formula_text = formula.get('formula_text', '')
                    info += f"- Complex formula in {sheet}!{cell} (Complexity: {complexity}/10): {formula_text}\n"
                if len(complex_formulas) > 3:
                    info += f"- ... {len(complex_formulas) - 3} more complex formulas\n"
            info += "\n"
        
        # Add macro information
        macros = euda_data.get('macros', [])
        if macros:
            info += f"Contains {len(macros)} macros.\n"
            for i, macro in enumerate(macros[:3]):
                name = macro.get('name', 'Unknown')
                complexity = macro.get('complexity', 0)
                risk_level = macro.get('risk_level', 'UNKNOWN')
                info += f"- Macro '{name}' (Complexity: {complexity}/10, Risk: {risk_level})\n"
            if len(macros) > 3:
                info += f"- ... {len(macros) - 3} more macros\n"
            info += "\n"
        
        # Add connection information
        connections = euda_data.get('connections', [])
        if connections:
            info += f"Contains {len(connections)} external connections.\n"
            for i, connection in enumerate(connections[:3]):
                conn_type = connection.get('type', 'Unknown')
                target = connection.get('target', 'Unknown')
                sensitive = "Sensitive" if connection.get('is_sensitive', False) else "Not sensitive"
                info += f"- {conn_type} connection to {target} ({sensitive})\n"
            if len(connections) > 3:
                info += f"- ... {len(connections) - 3} more connections\n"
        
        return info
    
    def process_query(self, query: str, query_type: str = 'general_query') -> str:
        """
        Process a user query about EUDAs.
        
        Args:
            query: The user's query text
            query_type: Type of query (general_query, remediation_advice, compliance_check, complexity_explanation)
            
        Returns:
            LLM response to the query
        """
        try:
            # Generate embeddings for the query
            query_embedding = self.embedding_service.generate_text_embedding(query)
            
            # Find similar EUDAs
            similar_eudas = self.vector_db_service.find_similar_eudas(
                query_embedding,
                limit=3,
                threshold=0.5
            )
            
            if not similar_eudas:
                return "I couldn't find any relevant EUDA information to answer your query. Please try rephrasing your question or provide more details about the specific EUDA you're interested in."
            
            # Get most similar EUDA
            most_similar_euda_id = similar_eudas[0]['id']
            euda_data = self.vector_db_service.get_euda_by_id(most_similar_euda_id)
            
            if not euda_data:
                return "I found a relevant EUDA, but couldn't retrieve its details. Please try again later."
            
            # Format EUDA information
            euda_info = self._format_euda_info(euda_data)
            
            # Select template based on query type
            if query_type not in self.prompt_templates:
                query_type = 'general_query'
                
            template = self.prompt_templates[query_type]
            
            # Generate prompt
            prompt = template.substitute(
                euda_info=euda_info,
                query=query
            )
            
            # Query LLM
            response = self.query_llm