import logging
from config import ANALYSIS_CONFIG

logger = logging.getLogger(__name__)

class ComplexityCalculator:
    """Calculate the complexity of an Excel EUDA based on various factors."""
    
    def __init__(self, workbook_data):
        """Initialize with workbook data from the Excel parser."""
        self.workbook_data = workbook_data
        logger.info(f"Initializing complexity calculator for {workbook_data['filename']}")
    
    def calculate(self):
        """
        Calculate the complexity score of the Excel EUDA.
        
        Returns:
            dict: A dictionary containing complexity metrics and total score
        """
        logger.info(f"Calculating complexity for {self.workbook_data['filename']}")
        
        # Initialize complexity metrics
        complexity = {
            'sheet_count': len(self.workbook_data['sheets']),
            'cell_count': self._count_total_cells(),
            'formula_count': self._count_formulas(),
            'formula_complexity': self._calculate_formula_complexity(),
            'structural_complexity': self._calculate_structural_complexity(),
            'connection_complexity': self._calculate_connection_complexity(),
            'total_score': 0
        }
        
        # Calculate total complexity score (0-100)
        # Weightings: formulas (40%), structure (30%), cells (20%), connections (10%)
        
        # Normalize cell count (0-20 points)
        cell_score = min(20, (complexity['cell_count'] / 10000) * 20)
        
        # Formula complexity (0-40 points)
        formula_score = min(40, complexity['formula_complexity'] * 40 / 100)
        
        # Structural complexity (0-30 points)
        structural_score = min(30, complexity['structural_complexity'] * 30 / 100)
        
        # Connection complexity (0-10 points)
        connection_score = min(10, complexity['connection_complexity'] * 10 / 100)
        
        # Calculate total score
        complexity['total_score'] = round(cell_score + formula_score + structural_score + connection_score, 1)
        
        # Determine complexity level
        thresholds = ANALYSIS_CONFIG['complexity_thresholds']
        if complexity['total_score'] < thresholds['low']:
            complexity['level'] = 'Low'
        elif complexity['total_score'] < thresholds['medium']:
            complexity['level'] = 'Medium'
        elif complexity['total_score'] < thresholds['high']:
            complexity['level'] = 'High'
        else:
            complexity['level'] = 'Very High'
        
        logger.info(f"Complexity calculation completed: {complexity['level']} ({complexity['total_score']})")
        return complexity
    
    def _count_total_cells(self):
        """Count the total number of non-empty cells in the workbook."""
        total_cells = 0
        for sheet_name, sheet_data in self.workbook_data['sheets'].items():
            total_cells += sheet_data['cell_count']
        return total_cells
    
    def _count_formulas(self):
        """Count the total number of formulas in the workbook."""
        formula_count = 0
        for sheet_name, sheet_data in self.workbook_data['sheets'].items():
            formula_count += len(sheet_data['formula_cells'])
        return formula_count
    
    def _calculate_formula_complexity(self):
        """
        Calculate the complexity of formulas in the workbook.
        
        Returns:
            float: Formula complexity score (0-100)
        """
        # If no formulas, return 0
        formula_count = self._count_formulas()
        if formula_count == 0:
            return 0
        
        complex_functions = set(FORMULA_CONFIG['complex_functions'])
        complex_formula_count = 0
        nested_formula_count = 0
        array_formula_count = 0
        
        for sheet_name, sheet_data in self.workbook_data['sheets'].items():
            for formula_cell in sheet_data['formula_cells']:
                formula = formula_cell['formula']
                
                # Check for complex functions
                for func in complex_functions:
                    if func in formula.upper():
                        complex_formula_count += 1
                        break
                
                # Check for nested formulas (approximation based on parentheses)
                if formula.count('(') > 2:
                    nested_formula_count += 1
                
                # Check for array formulas (approximation)
                if '{' in formula and '}' in formula:
                    array_formula_count += 1
        
        # Calculate formula complexity score (0-100)
        # 40% for complex functions, 40% for nested formulas, 20% for array formulas
        complex_ratio = min(1.0, complex_formula_count / formula_count)
        nested_ratio = min(1.0, nested_formula_count / formula_count)
        array_ratio = min(1.0, array_formula_count / formula_count)
        
        formula_complexity = (complex_ratio * 40) + (nested_ratio * 40) + (array_ratio * 20)
        return round(formula_complexity, 1)
    
    def _calculate_structural_complexity(self):
        """
        Calculate the structural complexity of the workbook.
        
        Returns:
            float: Structural complexity score (0-100)
        """
        # Initialize metrics
        total_sheets = len(self.workbook_data['sheets'])
        hidden_sheets = 0
        has_tables = 0
        has_charts = 0
        has_shapes = 0
        has_conditional_formatting = 0
        defined_names_count = len(self.workbook_data['defined_names'])
        
        # Count structural elements
        for sheet_name, sheet_data in self.workbook_data['sheets'].items():
            if sheet_data['hidden']:
                hidden_sheets += 1
            
            if sheet_data['has_tables']:
                has_tables += 1
            
            if sheet_data['has_charts']:
                has_charts += 1
            
            if sheet_data['has_shapes']:
                has_shapes += 1
            
            if sheet_data['has_conditional_formatting']:
                has_conditional_formatting += 1
        
        # Calculate structural complexity score (0-100)
        # Weightings: sheets (20%), hidden sheets (10%), tables (15%), 
        # charts (15%), shapes (10%), conditional formatting (15%), defined names (15%)
        sheet_score = min(20, (total_sheets / 10) * 20)
        hidden_sheet_score = 10 if hidden_sheets > 0 else 0
        tables_score = min(15, (has_tables / total_sheets) * 15)
        charts_score = min(15, (has_charts / total_sheets) * 15)
        shapes_score = min(10, (has_shapes / total_sheets) * 10)
        cond_format_score = min(15, (has_conditional_formatting / total_sheets) * 15)
        defined_names_score = min(15, (defined_names_count / 10) * 15)
        
        structural_complexity = (sheet_score + hidden_sheet_score + tables_score + 
                                charts_score + shapes_score + cond_format_score + 
                                defined_names_score)
        
        return round(structural_complexity, 1)
    
    def _calculate_connection_complexity(self):
        """
        Calculate the complexity related to external connections.
        
        Returns:
            float: Connection complexity score (0-100)
        """
        # Count connections
        connection_count = len(self.workbook_data['connections'])
        
        # Calculate connection complexity score (0-100)
        if connection_count == 0:
            return 0
        elif connection_count <= 2:
            return 40
        elif connection_count <= 5:
            return 70
        else:
            return 100
