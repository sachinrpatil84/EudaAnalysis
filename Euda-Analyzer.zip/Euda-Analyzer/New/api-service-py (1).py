#!/usr/bin/env python3
"""
API service for EUDA analyzer application.
Provides endpoints for analyzing EUDAs and querying analysis results.
"""

import logging
import os
from typing import Dict, Any, List, Optional
from flask import Flask, request, jsonify, abort
import json

from euda_analyzer import EUDAAnalyzer
from embedding_service import EmbeddingService
from vector_db_service import VectorDBService
from db_connector import DBConnector
from config import Config

logger = logging.getLogger(__name__)

class APIService:
    """
    API service for EUDA analyzer application.
    """
    
    def __init__(self, config_path: str = 'config.ini'):
        """
        Initialize the API service.
        
        Args:
            config_path: Path to configuration file
        """
        # Load configuration
        self.config = Config(config_path)
        
        # Initialize services
        db_connector = DBConnector(
            self.config.get('Database', 'host'),
            self.config.get('Database', 'port'),
            self.config.get('Database', 'database'),
            self.config.get('Database', 'user'),
            self.config.get('Database', 'password')
        )
        
        self.embedding_service = EmbeddingService(
            self.config.get('Embedding', 'model_id'),
            self.config.get('Embedding', 'aws_region'),
            self.config.get('Embedding', 'aws_access_key_id'),
            self.config.get('Embedding', 'aws_secret_access_key')
        )
        
        self.vector_db_service = VectorDBService(db_connector)
        
        self.analyzer = EUDAAnalyzer(
            embedding_service=self.embedding_service,
            vector_db_service=self.vector_db_service
        )
        
        # Create Flask app
        self.app = Flask(__name__)
        self.setup_routes()
        
        logger.info("Initialized APIService")
    
    def setup_routes(self):
        """Set up API routes."""
        # Route for health check
        @self.app.route('/health', methods=['GET'])
        def health_check():
            return jsonify({'status': 'ok'})
        
        # Route for analyzing an EUDA
        @self.app.route('/analyze', methods=['POST'])
        def analyze_euda():
            if 'file' not in request.files:
                return jsonify({'error': 'No file provided'}), 400
            
            file = request.files['file']
            if file.filename == '':
                return jsonify({'error': 'No selected file'}), 400
            
            if not file.filename.endswith(('.xlsx', '.xls', '.xlsm')):
                return jsonify({'error': 'File must be an Excel file (.xlsx, .xls, .xlsm)'}), 400
            
            # Save file temporarily
            temp_path = f"/tmp/{file.filename}"
            file.save(temp_path)
            
            try:
                # Analyze the file
                analysis_result = self.analyzer.analyze(temp_path)
                
                # Clean up temporary file
                os.remove(temp_path)
                
                # Remove embeddings from response as they are large
                if 'embeddings' in analysis_result:
                    del analysis_result['embeddings']
                
                return jsonify(analysis_result)
            except Exception as e:
                logger.error(f"Error analyzing file: {str(e)}")
                
                # Clean up temporary file
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                
                return jsonify({'error': str(e)}), 500
        
        # Route for searching similar EUDAs
        @self.app.route('/search', methods=['POST'])
        def search_eudas():
            data = request.json
            if not data or 'query' not in data:
                return jsonify({'error': 'No query provided'}), 400
            
            query = data['query']
            limit = data.get('limit', 10)
            
            try:
                similar_eudas = self.analyzer.search_similar_eudas(query, limit)
                return jsonify(similar_eudas)
            except Exception as e:
                logger.error(f"Error searching EUDAs: {str(e)}")
                return jsonify({'error': str(e)}), 500
        
        # Route for getting EUDA by ID
        @self.app.route('/eudas/<int:euda_id>', methods=['GET'])
        def get_euda(euda_id):
            try:
                euda = self.analyzer.get_euda_by_id(euda_id)
                
                if not euda:
                    return jsonify({'error': 'EUDA not found'}), 404
                
                return jsonify(euda)
            except Exception as e:
                logger.error(f"Error getting EUDA: {str(e)}")
                return jsonify({'error': str(e)}), 500
        
        # Route for getting all EUDAs
        @self.app.route('/eudas', methods=['GET'])
        def get_all_eudas():
            try:
                limit = request.args.get('limit', 100, type=int)
                offset = request.args.get('offset', 0, type=int)
                
                eudas = self.analyzer.get_all_eudas(limit, offset)
                return jsonify(eudas)
            except Exception as e:
                logger.error(f"Error getting all EUDAs: {str(e)}")
                return jsonify({'error': str(e)}), 500
    
    def run(self, host: str = '0.0.0.0', port: int = 5000, debug: bool = False):
        """
        Run the API server.
        
        Args:
            host: Host to bind the server to
            port: Port to bind the server to
            debug: Whether to run in debug mode
        """
        self.app.run(host=host, port=port, debug=debug)
