#!/usr/bin/env python3
"""
Main entry point for EUDA Analyzer application.
This script orchestrates the analysis of Excel EUDAs, extracts their characteristics,
and stores them in a vector database for later querying.
"""

import os
import argparse
import logging
from pathlib import Path
from typing import List

from config import Config
from euda_analyzer import EUDAAnalyzer
from db_connector import DBConnector
from excel_parser import ExcelParser
from vector_db_service import VectorDBService
from embedding_service import EmbeddingService

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("euda_analyzer.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='Analyze Excel EUDAs and store in vector database')
    parser.add_argument(
        '--input', '-i', 
        type=str, 
        help='Path to single Excel file or directory containing Excel files'
    )
    parser.add_argument(
        '--recursive', '-r',
        action='store_true',
        help='Recursively search for Excel files in the input directory'
    )
    parser.add_argument(
        '--config', '-c',
        type=str, 
        default='config.ini',
        help='Path to configuration file'
    )
    return parser.parse_args()


def find_excel_files(input_path: str, recursive: bool = False) -> List[str]:
    """Find all Excel files in the given path."""
    excel_extensions = ['.xlsx', '.xls', '.xlsm']
    excel_files = []
    
    input_path = Path(input_path)
    
    if input_path.is_file() and input_path.suffix.lower() in excel_extensions:
        excel_files.append(str(input_path))
    elif input_path.is_dir():
        if recursive:
            for ext in excel_extensions:
                excel_files.extend([str(p) for p in input_path.glob(f'**/*{ext}')])
        else:
            for ext in excel_extensions:
                excel_files.extend([str(p) for p in input_path.glob(f'*{ext}')])
    
    return excel_files


def main():
    """Main function to run the EUDA Analyzer."""
    args = parse_arguments()
    
    try:
        # Load configuration
        config = Config(args.config)
        logger.info(f"Configuration loaded from {args.config}")
        
        # Initialize services
        db_connector = DBConnector(
            config.get('Database', 'host'),
            config.get('Database', 'port'),
            config.get('Database', 'database'),
            config.get('Database', 'user'),
            config.get('Database', 'password')
        )
        
        embedding_service = EmbeddingService(
            config.get('Embedding', 'model_id'),
            config.get('Embedding', 'aws_region'),
            config.get('Embedding', 'aws_access_key_id'),
            config.get('Embedding', 'aws_secret_access_key')
        )
        
        vector_db_service = VectorDBService(db_connector)
        
        # Find Excel files to analyze
        if not args.input:
            logger.error("No input path specified. Use --input to specify a file or directory.")
            return 1
        
        excel_files = find_excel_files(args.input, args.recursive)
        
        if not excel_files:
            logger.error(f"No Excel files found in {args.input}")
            return 1
        
        logger.info(f"Found {len(excel_files)} Excel files to analyze")
        
        # Initialize analyzer
        analyzer = EUDAAnalyzer(
            embedding_service=embedding_service,
            vector_db_service=vector_db_service
        )
        
        # Process each file
        for excel_file in excel_files:
            try:
                logger.info(f"Analyzing {excel_file}")
                analyzer.analyze(excel_file)
                logger.info(f"Successfully analyzed and stored {excel_file}")
            except Exception as e:
                logger.error(f"Failed to analyze {excel_file}: {str(e)}")
        
        logger.info("Analysis complete")
        return 0
    
    except Exception as e:
        logger.error(f"Error in main execution: {str(e)}", exc_info=True)
        return 1


if __name__ == "__main__":
    exit_code = main()
    exit(exit_code)
