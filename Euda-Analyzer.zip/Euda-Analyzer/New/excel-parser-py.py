import os
import logging
import openpyxl
import xlrd
from openpyxl.utils.exceptions import InvalidFileException

logger = logging.getLogger(__name__)

class ExcelParser:
    """Parser for Excel files to extract data needed for EUDA analysis."""
    
    def __init__(self, file_path):
        """Initialize the parser with the Excel file path."""
        self.file_path = file_path
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Excel file not found: {file_path}")
        
        self.file_extension = os.path.splitext(file_path)[1].lower()
        logger.info(f"Initializing parser for {file_path} with extension {self.file_extension}")
    
    def parse(self):
        """
        Parse the Excel file and extract relevant data.
        
        Returns:
            dict: A dictionary containing the parsed workbook data
        """
        if self.file_extension in ['.xlsx', '.xlsm', '.xlsb']:
            return self._parse_xlsx()
        elif self.file_extension in ['.xls']:
            return self._parse_xls()
        else:
            raise ValueError(f"Unsupported file extension: {self.file_extension}")
    
    def _parse_xlsx(self):
        """Parse modern Excel file formats (.xlsx, .xlsm)."""
        try:
            workbook = openpyxl.load_workbook(self.file_path, read_only=True, keep_vba=True, data_only=False)
            
            # Extract basic workbook information
            workbook_data = {
                'filename': os.path.basename(self.file_path),
                'file_path': self.file_path,
                'file_size': os.path.getsize(self.file_path),
                'has_macros': self.file_extension == '.xlsm',
                'sheets': {},
                'defined_names': [],
                'connections': [],
            }
            
            # Extract defined names
            for name in workbook.defined_names.values():
                workbook_data['defined_names'].append({
                    'name': name.name,
                    'value': name.value,
                })
            
            # Process each sheet
            for sheet_name in workbook.sheetnames:
                sheet = workbook[sheet_name]
                
                # Extract sheet data
                sheet_data = {
                    'name': sheet_name,
                    'hidden': sheet.sheet_state != 'visible',
                    'cell_count': 0,
                    'formula_cells': [],
                    'named_ranges': [],
                    'data_validation': [],
                    'has_tables': False,
                    'has_charts': False,
                    'has_shapes': False,
                    'has_conditional_formatting': len(sheet.conditional_formatting) > 0,
                }
                
                # Extract cell data
                for row_idx, row in enumerate(sheet.iter_rows(), 1):
                    for col_idx, cell in enumerate(row, 1):
                        if cell.value is not None:
                            sheet_data['cell_count'] += 1
                            
                            # Check for formulas
                            if cell.data_type == 'f':
                                sheet_data['formula_cells'].append({
                                    'address': f"{cell.column_letter}{cell.row}",
                                    'formula': cell.value,
                                })
                
                # Check for tables and charts
                try:
                    sheet_data['has_tables'] = len(sheet.tables) > 0
                except (AttributeError, NotImplementedError):
                    # Some versions of openpyxl or read-only mode don't support this
                    pass
                
                try:
                    sheet_data['has_charts'] = len(sheet._charts) > 0
                except (AttributeError, NotImplementedError):
                    pass
                
                try:
                    sheet_data['has_shapes'] = len(sheet._shapes) > 0
                except (AttributeError, NotImplementedError):
                    pass
                
                # Add sheet data to workbook
                workbook_data['sheets'][sheet_name] = sheet_data
            
            # Try to extract data connections (may not be available in read-only mode)
            try:
                for connection in workbook._external_links:
                    if hasattr(connection, 'file_link'):
                        workbook_data['connections'].append({
                            'type': 'external_link',
                            'target': connection.file_link.target,
                        })
            except (AttributeError, NotImplementedError):
                pass
            
            workbook.close()
            return workbook_data
            
        except InvalidFileException as e:
            logger.error(f"Invalid Excel file: {self.file_path} - {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error parsing Excel file: {self.file_path} - {str(e)}")
            raise
    
    def _parse_xls(self):
        """Parse legacy Excel file format (.xls)."""
        try:
            workbook = xlrd.open_workbook(self.file_path, formatting_info=True)
            
            # Extract basic workbook information
            workbook_data = {
                'filename': os.path.basename(self.file_path),
                'file_path': self.file_path,
                'file_size': os.path.getsize(self.file_path),
                'has_macros': False,  # Can't easily detect in .xls format
                'sheets': {},
                'defined_names': [],
                'connections': [],
            }
            
            # Extract defined names
            for i in range(workbook.nnames):
                name = workbook.name_obj_list[i]
                workbook_data['defined_names'].append({
                    'name': name.name,
                    'formula': name.formula_text,
                })
            
            # Process each sheet
            for sheet_idx in range(workbook.nsheets):
                sheet = workbook.sheet_by_index(sheet_idx)
                sheet_name = sheet.name
                
                # Extract sheet data
                sheet_data = {
                    'name': sheet_name,
                    'hidden': sheet.visibility != 0,  # 0 = visible
                    'cell_count': 0,
                    'formula_cells': [],
                    'named_ranges': [],
                    'data_validation': [],
                    'has_tables': False,  # Not directly detectable in xlrd
                    'has_charts': False,  # Not directly detectable in xlrd
                    'has_shapes': False,  # Not directly detectable in xlrd
                    'has_conditional_formatting': False,  # Not easily detectable in xlrd
                }
                
                # Extract cell data
                for row_idx in range(sheet.nrows):
                    for col_idx in range(sheet.ncols):
                        cell_type = sheet.cell_type(row_idx, col_idx)
                        cell_value = sheet.cell_value(row_idx, col_idx)
                        
                        if cell_value:
                            sheet_data['cell_count'] += 1
                            
                            # Check for formulas (formula results are stored, not formulas themselves in xlrd)
                            if cell_type == xlrd.XL_CELL_FORMULA:
                                sheet_data['formula_cells'].append({
                                    'address': f"{xlrd.colname(col_idx)}{row_idx+1}",
                                    'formula': "Unknown (Legacy Format)",  # Can't easily get formula text in xlrd
                                })
                
                # Add sheet data to workbook
                workbook_data['sheets'][sheet_name] = sheet_data
            
            return workbook_data
            
        except Exception as e:
            logger.error(f"Error parsing legacy Excel file: {self.file_path} - {str(e)}")
            raise
