import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Database configuration
DB_CONFIG = {
    'name': os.getenv('DB_NAME', 'euda_analyzer'),
    'user': os.getenv('DB_USER', 'postgres'),
    'password': os.getenv('DB_PASSWORD', ''),
    'host': os.getenv('DB_HOST', 'localhost'),
    'port': os.getenv('DB_PORT', '5432'),
}

# AWS configuration
AWS_CONFIG = {
    'region': os.getenv('AWS_REGION', 'us-east-1'),
    'access_key_id': os.getenv('AWS_ACCESS_KEY_ID', ''),
    'secret_access_key': os.getenv('AWS_SECRET_ACCESS_KEY', ''),
}

# Model configuration
MODEL_CONFIG = {
    'titan_text_model_id': os.getenv('TITAN_TEXT_MODEL_ID', 'amazon.titan-text-embed-v2:0'),
    'titan_image_model_id': os.getenv('TITAN_IMAGE_MODEL_ID', 'amazon.titan-image-v1'),
    'llm_model_id': os.getenv('LLM_MODEL_ID', 'anthropic.claude-3-sonnet-20240229-v1:0'),
}

# Analysis configuration
ANALYSIS_CONFIG = {
    'complexity_thresholds': {
        'low': 30,
        'medium': 60,
        'high': 90,
    },
    'risk_thresholds': {
        'low': 30,
        'medium': 60,
        'high': 90,
    },
    'sensitive_data_patterns': [
        r'\b(?:\d[ -]*?){13,16}\b',  # Credit card numbers
        r'\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b',  # SSN
        r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',  # Email
        r'\b(?:password|passwd|pwd|secret|key|token)\b',  # Sensitive keywords
    ],
    'compliance_frameworks': [
        'GDPR',
        'HIPAA',
        'PCI-DSS',
        'SOX',
        'CCPA',
    ],
}

# Formula analysis configuration
FORMULA_CONFIG = {
    'complex_functions': [
        'VLOOKUP', 'HLOOKUP', 'INDEX', 'MATCH', 'INDIRECT', 
        'OFFSET', 'SUMIFS', 'SUMPRODUCT', 'COUNTIFS', 'AVERAGEIFS',
        'IF', 'IFERROR', 'IFS', 'SWITCH', 'CHOOSE',
        'QUERY', 'ARRAYFORMULA', 'LAMBDA', 'LET', 'MAP', 'REDUCE',
        'DSUM', 'DCOUNT', 'DAVERAGE', 'DGET', 'DMAX', 'DMIN',
    ],
    'high_risk_functions': [
        'INDIRECT', 'CELL', 'HYPERLINK', 'WEBSERVICE', 'FILTERXML',
        'DDESERVICES', 'DDELINK',
    ],
}

# Macro analysis configuration
MACRO_CONFIG = {
    'high_risk_operations': [
        'activexobjects', 'createobject', 'shell', 'wscript', 
        'filesystemobject', 'adodb', 'vbe', 'environ',
        'getobject', 'scriptengine', 'run', 'system',
    ],
}

# Connection analysis configuration
CONNECTION_CONFIG = {
    'connection_types': [
        'ODBC', 'OLEDB', 'SQL', 'JDBC', 'ADO', 'Web Query',
        'PowerQuery', 'PowerPivot', 'External Data',
    ],
}
