import logging

logger = logging.getLogger(__name__)

def create_tables_if_not_exist(conn):
    """Create the necessary database tables if they don't exist."""
    try:
        with conn.cursor() as cursor:
            # Enable pgvector extension if not already enabled
            cursor.execute("CREATE EXTENSION IF NOT EXISTS vector;")
            
            # Create main table for EUDA analyses
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS euda_analyses (
                    id SERIAL PRIMARY KEY,
                    filename VARCHAR(255) NOT NULL,
                    file_path TEXT NOT NULL,
                    complexity_score FLOAT NOT NULL,
                    risk_level VARCHAR(50) NOT NULL,
                    has_sensitive_data BOOLEAN NOT NULL,
                    has_macros BOOLEAN NOT NULL,
                    has_external_connections BOOLEAN NOT NULL,
                    formula_count INTEGER NOT NULL,
                    summary TEXT NOT NULL,
                    analysis_data JSONB NOT NULL,
                    embedding vector(1536) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)
            
            # Create index on embedding for similarity search
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS euda_analyses_embedding_idx 
                ON euda_analyses 
                USING ivfflat (embedding vector_cosine_ops)
                WITH (lists = 100);
            """)
            
            # Create table for compliance issues
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS compliance_issues (
                    id SERIAL PRIMARY KEY,
                    analysis_id INTEGER REFERENCES euda_analyses(id) ON DELETE CASCADE,
                    issue_description TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)
            
            # Create table for data sources
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS data_sources (
                    id SERIAL PRIMARY KEY,
                    analysis_id INTEGER REFERENCES euda_analyses(id) ON DELETE CASCADE,
                    source_name TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)
            
            # Create table for macros
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS macros (
                    id SERIAL PRIMARY KEY,
                    analysis_id INTEGER REFERENCES euda_analyses(id) ON DELETE CASCADE,
                    macro_name VARCHAR(255) NOT NULL,
                    macro_description TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)
            
            conn.commit()
            logger.info("Database tables created successfully")
    except Exception as e:
        conn.rollback()
        logger.error(f"Error creating database tables: {str(e)}")
        raise
