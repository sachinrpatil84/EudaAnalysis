#!/usr/bin/env python3
"""
Utility functions for EUDA analyzer.
"""

import os
import re
import logging
import json
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)

def clean_filename(filename: str) -> str:
    """
    Remove path and extension from filename.
    
    Args:
        filename: Full filename with path
        
    Returns:
        Clean filename without path and extension
    """
    base = os.path.basename(filename)
    name, _ = os.path.splitext(base)
    return name

def extract_key_words(text: str) -> List[str]:
    """
    Extract key words from a text string.
    
    Args:
        text: Text to extract keywords from
        
    Returns:
        List of keywords
    """
    # Simple implementation - could be enhanced with NLP
    words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())
    # Remove common stopwords
    stopwords = {'and', 'the', 'is', 'in', 'it', 'to', 'for', 'with', 'on', 'at', 'from', 'by'}
    return [w for w in words if w not in stopwords]

def generate_euda_description(excel_data: Dict[str, Any]) -> str:
    """
    Generate a descriptive summary of an EUDA based on analysis results.
    
    Args:
        excel_data: Dictionary containing Excel analysis data
        
    Returns:
        A descriptive string summarizing the EUDA
    """
    filename = clean_filename(excel_data.get('filename', 'Unknown EUDA'))
    
    # Basic information
    description = f"EUDA: {filename}\n\n"
    
    # Overview statistics
    sheet_count = len(excel_data.get('sheets', []))
    formula_count = len(excel_data.get('formulas', []))
    macro_count = len(excel_data.get('macros', []))
    connection_count = len(excel_data.get('connections', []))
    
    description += f"Overview:\n"
    description += f"- Contains {sheet_count} worksheet{'s' if sheet_count != 1 else ''}\n"
    description += f"- Uses {formula_count} formula{'s' if formula_count != 1 else ''}\n"
    description += f"- Contains {macro_count} macro{'s' if macro_count != 1 else ''}\n"
    description += f"- Has {connection_count} external connection{'s' if connection_count != 1 else ''}\n"
    
    # Complexity and risk assessment
    complexity_score = excel_data.get('complexity_score', 0)
    complexity_category = categorize_complexity(complexity_score)
    
    risk_score = excel_data.get('risk_score', 0)
    risk_category = categorize_risk(risk_score)
    
    data_sensitivity = excel_data.get('data_sensitivity', 'UNKNOWN')
    
    description += f"\nAssessment:\n"
    description += f"- Complexity: {complexity_category} ({complexity_score:.2f}/10)\n"
    description += f"- Risk: {risk_category} ({risk_score:.2f}/10)\n"
    description += f"- Data Sensitivity: {data_sensitivity}\n"
    
    # Add compliance information if available
    compliance_status = excel_data.get('compliance_status', {})
    if compliance_status:
        description += "\nCompliance Status:\n"
        for standard, status in compliance_status.items():
            description += f"- {standard}: {status}\n"
    
    # Add formula highlights if available
    if formula_count > 0:
        complex_formulas = [f for f in excel_data.get('formulas', []) if f.get('complexity', 0) > 5]
        if complex_formulas:
            description += f"\nHighlights {len(complex_formulas)} complex formula{'s' if len(complex_formulas) > 1 else ''}:\n"
            for i, formula in enumerate(complex_formulas[:3]):  # Show top 3 complex formulas
                sheet = formula.get('sheet_name', 'Unknown')
                cell = formula.get('cell_reference', 'Unknown')
                description += f"- {sheet}!{cell}: Complexity {formula.get('complexity', 0):.1f}/10\n"
            if len(complex_formulas) > 3:
                description += f"- ... and {len(complex_formulas) - 3} more complex formulas\n"
    
    # Add macro highlights if available
    if macro_count > 0:
        high_risk_macros = [m for m in excel_data.get('macros', []) if m.get('risk_level') in ['HIGH', 'MEDIUM']]
        if high_risk_macros:
            description += f"\nContains {len(high_risk_macros)} potentially risky macro{'s' if len(high_risk_macros) > 1 else ''}:\n"
            for i, macro in enumerate(high_risk_macros[:3]):  # Show top 3 risky macros
                name = macro.get('name', 'Unknown')
                risk = macro.get('risk_level', 'UNKNOWN')
                description += f"- {name}: Risk level {risk}\n"
            if len(high_risk_macros) > 3:
                description += f"- ... and {len(high_risk_macros) - 3} more risky macros\n"
    
    # Add connection highlights if available
    if connection_count > 0:
        sensitive_connections = [c for c in excel_data.get('connections', []) if c.get('is_sensitive', False)]
        if sensitive_connections:
            description += f"\nContains {len(sensitive_connections)} sensitive data connection{'s' if len(sensitive_connections) > 1 else ''}:\n"
            for i, conn in enumerate(sensitive_connections[:3]):  # Show top 3 sensitive connections
                conn_type = conn.get('type', 'Unknown')
                target = conn.get('target', 'Unknown')
                description += f"- {conn_type} connection to {target}\n"
            if len(sensitive_connections) > 3:
                description += f"- ... and {len(sensitive_connections) - 3} more sensitive connections\n"
    
    # Add summary
    description += f"\nSummary: This EUDA is a {complexity_category.lower()} complexity Excel application "
    description += f"with {risk_category.lower()} risk level and {data_sensitivity.lower()} data sensitivity. "
    
    if sheet_count > 5:
        description += f"It is a large workbook with {sheet_count} sheets. "
    
    if formula_count > 50:
        description += f"It makes extensive use of formulas ({formula_count} in total). "
    
    if macro_count > 0:
        description += f"It contains {macro_count} VBA macros. "
    
    if connection_count > 0:
        description += f"It connects to {connection_count} external data sources. "
    
    # Recommendations
    description += "\n\nRecommendations:\n"
    
    if complexity_score > 7:
        description += "- Consider breaking down this complex EUDA into smaller components\n"
    
    if risk_score > 7:
        description += "- This EUDA has high risk - review security controls and data access\n"
    
    if data_sensitivity in ['HIGH', 'CRITICAL']:
        description += "- Contains sensitive data - ensure appropriate controls are in place\n"
    
    if macro_count > 0 and any(m.get('risk_level') == 'HIGH' for m in excel_data.get('macros', [])):
        description += "- High-risk macros present - perform security review\n"
    
    if connection_count > 0 and any(c.get('is_sensitive') for c in excel_data.get('connections', [])):
        description += "- Sensitive data connections - ensure data protection in place\n"
    
    return description

def categorize_complexity(score: float) -> str:
    """Categorize complexity score into a descriptive category."""
    if score < 3:
        return "LOW"
    elif score < 7:
        return "MEDIUM"
    else:
        return "HIGH"

def categorize_risk(score: float) -> str:
    """Categorize risk score into a descriptive category."""
    if score < 3:
        return "LOW"
    elif score < 7:
        return "MEDIUM"
    else:
        return "HIGH"

def parse_json_safely(json_string: str, default=None) -> Any:
    """Parse JSON string with error handling."""
    try:
        return json.loads(json_string)
    except Exception as e:
        logger.warning(f"Error parsing JSON: {str(e)}")
        return default if default is not None else {}

def format_bytes(size: int) -> str:
    """Format bytes to human-readable string."""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size < 1024 or unit == 'GB':
            return f"{size:.2f} {unit}"
        size /= 1024

def truncate_string(text: str, max_length: int = 50) -> str:
    """Truncate string to maximum length with ellipsis."""
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + "..."

def get_sheet_names_from_excel_data(excel_data: Dict[str, Any]) -> List[str]:
    """Extract sheet names from excel data."""
    return excel_data.get('sheets', [])

def get_formula_count_by_sheet(excel_data: Dict[str, Any]) -> Dict[str, int]:
    """Count formulas per sheet."""
    counts = {}
    for formula in excel_data.get('formulas', []):
        sheet_name = formula.get('sheet_name', 'Unknown')
        counts[sheet_name] = counts.get(sheet_name, 0) + 1
    return counts

def get_high_risk_elements(excel_data: Dict[str, Any]) -> Dict[str, List[str]]:
    """Get high risk elements from EUDA analysis."""
    result = {"macros": [], "connections": [], "formulas": []}
    
    # Check for high risk macros
    for macro in excel_data.get('macros', []):
        if macro.get('risk_level') == 'HIGH':
            result["macros"].append(macro.get('name', 'Unknown macro'))
    
    # Check for sensitive connections
    for conn in excel_data.get('connections', []):
        if conn.get('is_sensitive', False):
            result["connections"].append(f"{conn.get('type', 'Unknown')} to {conn.get('target', 'Unknown')}")
    
    # Check for complex formulas
    for formula in excel_data.get('formulas', []):
        if formula.get('complexity', 0) > 7:
            sheet = formula.get('sheet_name', 'Unknown')
            cell = formula.get('cell_reference', 'Unknown')
            result["formulas"].append(f"{sheet}!{cell}")
    
    return result
