from src.config import VECTOR_DIMENSION
from src.database.db_connector import DatabaseConnector
import logging

logger = logging.getLogger(__name__)

class DatabaseSchema:
    """Handles database schema creation and management."""
    
    def __init__(self, db_connector=None):
        """Initialize with a database connector."""
        self.db_connector = db_connector or DatabaseConnector()
        
    def setup_database(self):
        """Set up the required database schema for EUDA analysis."""
        try:
            # Connect to the database
            conn = self.db_connector.connect()
            
            # Create extension if not exists
            self.db_connector.execute_query("CREATE EXTENSION IF NOT EXISTS vector")
            
            # Create EUDA table
            self._create_euda_table()
            
            # Create macros table
            self._create_macros_table()
            
            # Create formulas table
            self._create_formulas_table()
            
            # Create connections table
            self._create_connections_table()
            
            # Create embeddings table
            self._create_embeddings_table()
            
            logger.info("Database schema setup completed successfully")
            return True
        except Exception as e:
            logger.error(f"Error setting up database schema: {e}")
            raise
            
    def _create_euda_table(self):
        """Create the main EUDA table."""
        query = """
        CREATE TABLE IF NOT EXISTS eudas (
            id SERIAL PRIMARY KEY,
            file_name TEXT NOT NULL,
            file_path TEXT NOT NULL,
            file_size BIGINT NOT NULL,
            created_date TIMESTAMP,
            modified_date TIMESTAMP,
            author TEXT,
            complexity_score FLOAT,
            complexity_level TEXT CHECK (complexity_level IN ('low', 'medium', 'high')),
            risk_score FLOAT,
            data_sensitivity TEXT CHECK (data_sensitivity IN ('low', 'medium', 'high')),
            summary TEXT,
            purpose TEXT,
            has_macros BOOLEAN DEFAULT FALSE,
            has_external_connections BOOLEAN DEFAULT FALSE,
            sheet_count INTEGER,
            golden_data_sources TEXT[],
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(file_path)
        )
        """
        self.db_connector.execute_query(query)
        
    def _create_macros_table(self):
        """Create the table for storing macro information."""
        query = """
        CREATE TABLE IF NOT EXISTS euda_macros (
            id SERIAL PRIMARY KEY,
            euda_id INTEGER REFERENCES eudas(id) ON DELETE CASCADE,
            macro_name TEXT NOT NULL,
            macro_type TEXT,
            macro_code TEXT,
            macro_purpose TEXT,
            complexity_score FLOAT,
            risk_score FLOAT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(euda_id, macro_name)
        )
        """
        self.db_connector.execute_query(query)
        
    def _create_formulas_table(self):
        """Create the table for storing formula information."""
        query = """
        CREATE TABLE IF NOT EXISTS euda_formulas (
            id SERIAL PRIMARY KEY,
            euda_id INTEGER REFERENCES eudas(id) ON DELETE CASCADE,
            sheet_name TEXT NOT NULL,
            cell_reference TEXT NOT NULL,
            formula_text TEXT NOT NULL,
            complexity_score FLOAT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(euda_id, sheet_name, cell_reference)
        )
        """
        self.db_connector.execute_query(query)
        
    def _create_connections_table(self):
        """Create the table for storing connection information."""
        query = """
        CREATE TABLE IF NOT EXISTS euda_connections (
            id SERIAL PRIMARY KEY,
            euda_id INTEGER REFERENCES eudas(id) ON DELETE CASCADE,
            connection_type TEXT NOT NULL,
            connection_string TEXT,
            target_resource TEXT,
            sensitivity_level TEXT CHECK (sensitivity_level IN ('low', 'medium', 'high')),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
        self.db_connector.execute_query(query)
        
    def _create_embeddings_table(self):
        """Create the table for storing embeddings."""
        query = f"""
        CREATE TABLE IF NOT EXISTS euda_embeddings (
            id SERIAL PRIMARY KEY,
            euda_id INTEGER REFERENCES eudas(id) ON DELETE CASCADE,
            embedding_type TEXT NOT NULL,
            embedding vector({VECTOR_DIMENSION}),
            content_reference TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(euda_id, embedding_type, content_reference)
        )
        """
        self.db_connector.execute_query(query)
        
    def create_indexes(self):
        """Create relevant indexes to optimize query performance."""
        # Index on the vector column for similarity search
        index_query = """
        CREATE INDEX IF NOT EXISTS euda_embeddings_embedding_idx 
        ON euda_embeddings 
        USING ivfflat (embedding vector_cosine_ops)
        WITH (lists = 100)
        """
        self.db_connector.execute_query(index_query)
        
        # Other useful indexes
        self.db_connector.execute_query(
            "CREATE INDEX IF NOT EXISTS eudas_complexity_idx ON eudas(complexity_level)")
        self.db_connector.execute_query(
            "CREATE INDEX IF NOT EXISTS eudas_sensitivity_idx ON eudas(data_sensitivity)")
