import os
import json
import logging
import psycopg2
from psycopg2.extras import Json
from schema import create_tables_if_not_exist

logger = logging.getLogger(__name__)

class DbConnector:
    """Class for connecting to and interacting with the PostgreSQL database."""
    
    def __init__(self):
        """Initialize database connection using environment variables."""
        self.conn = None
        self.connect()
        create_tables_if_not_exist(self.conn)
    
    def connect(self):
        """Establish a connection to the PostgreSQL database."""
        try:
            self.conn = psycopg2.connect(
                dbname=os.getenv('DB_NAME', 'euda_analyzer'),
                user=os.getenv('DB_USER', 'postgres'),
                password=os.getenv('DB_PASSWORD', ''),
                host=os.getenv('DB_HOST', 'localhost'),
                port=os.getenv('DB_PORT', '5432')
            )
            logger.info("Connected to PostgreSQL database")
        except Exception as e:
            logger.error(f"Error connecting to database: {str(e)}")
            raise
    
    def store_analysis(self, analysis, embedding):
        """Store the EUDA analysis and its embedding in the database."""
        if not self.conn:
            self.connect()
        
        try:
            with self.conn.cursor() as cursor:
                # Insert the analysis
                cursor.execute(
                    """
                    INSERT INTO euda_analyses (
                        filename, 
                        file_path, 
                        complexity_score, 
                        risk_level, 
                        has_sensitive_data, 
                        has_macros, 
                        has_external_connections, 
                        formula_count,
                        summary,
                        analysis_data,
                        embedding
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING id
                    """,
                    (
                        analysis['filename'],
                        analysis['file_path'],
                        analysis['complexity']['total_score'],
                        analysis['risk_assessment']['risk_level'],
                        analysis['risk_assessment']['contains_sensitive_data'],
                        analysis['macros']['has_macros'],
                        analysis['connections']['has_external_connections'],
                        analysis['formulas']['total_count'],
                        analysis['summary'],
                        Json(analysis),
                        embedding
                    )
                )
                
                analysis_id = cursor.fetchone()[0]
                
                # Store compliance issues if any
                if analysis['risk_assessment']['compliance_issues']:
                    for issue in analysis['risk_assessment']['compliance_issues']:
                        cursor.execute(
                            """
                            INSERT INTO compliance_issues (
                                analysis_id, 
                                issue_description
                            ) VALUES (%s, %s)
                            """,
                            (analysis_id, issue)
                        )
                
                # Store data sources if any
                if analysis['connections']['data_sources']:
                    for source in analysis['connections']['data_sources']:
                        cursor.execute(
                            """
                            INSERT INTO data_sources (
                                analysis_id, 
                                source_name
                            ) VALUES (%s, %s)
                            """,
                            (analysis_id, source)
                        )
                
                # Store macros if any
                if analysis['macros']['has_macros']:
                    for macro in analysis['macros']['macros']:
                        cursor.execute(
                            """
                            INSERT INTO macros (
                                analysis_id, 
                                macro_name,
                                macro_description
                            ) VALUES (%s, %s, %s)
                            """,
                            (analysis_id, macro['name'], macro['description'])
                        )
                
                self.conn.commit()
                logger.info(f"Stored analysis for {analysis['filename']} with ID {analysis_id}")
                return analysis_id
                
        except Exception as e:
            self.conn.rollback()
            logger.error(f"Error storing analysis: {str(e)}")
            raise
    
    def search_similar_eudas(self, query_text, limit=5):
        """
        Search for similar EUDAs using vector similarity search.
        
        Args:
            query_text (str): The query text to search for
            limit (int): Maximum number of results to return
            
        Returns:
            list: List of similar EUDA analyses
        """
        from vector_embedder import VectorEmbedder
        
        if not self.conn:
            self.connect()
        
        try:
            # Create embedding for the query text
            embedder = VectorEmbedder()
            query_embedding = embedder.embed_text(query_text)
            
            with self.conn.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT 
                        id,
                        filename,
                        complexity_score,
                        risk_level,
                        has_sensitive_data,
                        has_macros,
                        formula_count,
                        summary,
                        1 - (embedding <=> %s) AS similarity
                    FROM euda_analyses
                    ORDER BY embedding <=> %s
                    LIMIT %s
                    """,
                    (query_embedding, query_embedding, limit)
                )
                
                columns = [desc[0] for desc in cursor.description]
                results = []
                
                for row in cursor.fetchall():
                    result = dict(zip(columns, row))
                    results.append(result)
                
                return results
                
        except Exception as e:
            logger.error(f"Error searching for similar EUDAs: {str(e)}")
            raise
    
    def get_analysis_by_id(self, analysis_id):
        """Retrieve a complete analysis by its ID."""
        if not self.conn:
            self.connect()
        
        try:
            with self.conn.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT analysis_data
                    FROM euda_analyses
                    WHERE id = %s
                    """,
                    (analysis_id,)
                )
                
                result = cursor.fetchone()
                if result:
                    return result[0]
                return None
                
        except Exception as e:
            logger.error(f"Error retrieving analysis: {str(e)}")
            raise
    
    def close(self):
        """Close the database connection."""
        if self.conn:
            self.conn.close()
            self.conn = None
            logger.info("Closed database connection")
