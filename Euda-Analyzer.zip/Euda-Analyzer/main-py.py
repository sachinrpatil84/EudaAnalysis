import os
import argparse
import logging
from dotenv import load_dotenv

from excel_parser import ExcelParser
from complexity_calculator import ComplexityCalculator
from risk_assessor import RiskAssessor
from connection_analyzer import ConnectionAnalyzer
from formula_analyzer import FormulaAnalyzer
from macro_analyzer import MacroAnalyzer
from db_connector import DbConnector
from vector_embedder import VectorEmbedder

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("euda_analyzer.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def analyze_euda(file_path, output_dir=None):
    """Analyze an Excel EUDA file and store the results in the vector database."""
    logger.info(f"Analyzing EUDA file: {file_path}")
    
    # Parse the Excel file
    parser = ExcelParser(file_path)
    workbook_data = parser.parse()
    
    # Analyze the Excel file
    complexity = ComplexityCalculator(workbook_data).calculate()
    risk = RiskAssessor(workbook_data).assess()
    connections = ConnectionAnalyzer(workbook_data).analyze()
    formulas = FormulaAnalyzer(workbook_data).analyze()
    macros = MacroAnalyzer(workbook_data).analyze()
    
    # Prepare analysis report
    analysis = {
        'file_path': file_path,
        'filename': os.path.basename(file_path),
        'complexity': complexity,
        'risk_assessment': risk,
        'connections': connections,
        'formulas': formulas,
        'macros': macros,
        'summary': generate_summary(complexity, risk, connections, formulas, macros)
    }
    
    # Create embeddings
    embedder = VectorEmbedder()
    embedding = embedder.embed_analysis(analysis)
    
    # Store in database
    db = DbConnector()
    db.store_analysis(analysis, embedding)
    
    # Save analysis report if output directory is provided
    if output_dir:
        save_analysis_report(analysis, output_dir)
    
    logger.info(f"Analysis completed for: {file_path}")
    return analysis

def generate_summary(complexity, risk, connections, formulas, macros):
    """Generate a summary of what the EUDA is doing based on analysis."""
    summary = f"This EUDA has a complexity score of {complexity['total_score']} out of 100. "
    
    # Add risk information
    risk_level = risk['risk_level']
    summary += f"It has been assessed as {risk_level} risk. "
    
    # Add data sensitivity
    if risk['contains_sensitive_data']:
        summary += "It contains sensitive data. "
    
    # Add connections information
    if connections['has_external_connections']:
        summary += f"The EUDA connects to {len(connections['data_sources'])} external data sources. "
    
    # Add formula information
    formula_count = formulas['total_count']
    if formula_count > 0:
        summary += f"It contains {formula_count} formulas"
        if formulas['complex_formulas_count'] > 0:
            summary += f", with {formulas['complex_formulas_count']} complex formulas. "
        else:
            summary += ". "
    
    # Add macro information
    if macros['has_macros']:
        summary += f"It contains {len(macros['macros'])} macros. "
    
    # Add purpose based on the analysis
    summary += "Based on the analysis, this EUDA appears to be "
    
    if connections['has_external_connections'] and formula_count > 10:
        summary += "a data processing application that imports and transforms data. "
    elif macros['has_macros'] and formulas['total_count'] > 20:
        summary += "an automated reporting tool with calculations. "
    elif complexity['total_score'] < 30 and not macros['has_macros']:
        summary += "a simple data collection or tracking spreadsheet. "
    else:
        summary += "a complex business application with multiple functionalities. "
    
    return summary

def save_analysis_report(analysis, output_dir):
    """Save the analysis report to a file."""
    import json
    os.makedirs(output_dir, exist_ok=True)
    filename = os.path.splitext(analysis['filename'])[0]
    output_path = os.path.join(output_dir, f"{filename}_analysis.json")
    
    with open(output_path, 'w') as f:
        json.dump(analysis, f, indent=2)
    
    logger.info(f"Analysis report saved to: {output_path}")

def analyze_directory(directory_path, output_dir=None):
    """Analyze all Excel files in a directory."""
    logger.info(f"Analyzing all Excel files in directory: {directory_path}")
    excel_extensions = ['.xlsx', '.xls', '.xlsm']
    
    analyzed_files = []
    for root, _, files in os.walk(directory_path):
        for file in files:
            if any(file.lower().endswith(ext) for ext in excel_extensions):
                file_path = os.path.join(root, file)
                try:
                    analysis = analyze_euda(file_path, output_dir)
                    analyzed_files.append({
                        'file_path': file_path,
                        'status': 'success'
                    })
                except Exception as e:
                    logger.error(f"Error analyzing {file_path}: {str(e)}")
                    analyzed_files.append({
                        'file_path': file_path,
                        'status': 'error',
                        'error': str(e)
                    })
    
    return analyzed_files

def main():
    """Main function to run the EUDA analyzer."""
    load_dotenv()
    
    parser = argparse.ArgumentParser(description='EUDA Analyzer')
    parser.add_argument('--file', help='Path to the Excel EUDA file to analyze')
    parser.add_argument('--dir', help='Path to directory containing Excel EUDA files to analyze')
    parser.add_argument('--output', help='Directory to save analysis reports')
    args = parser.parse_args()
    
    if args.file:
        analyze_euda(args.file, args.output)
    elif args.dir:
        analyze_directory(args.dir, args.output)
    else:
        parser.print_help()

if __name__ == '__main__':
    main()
