import os
import pandas as pd
import openpyxl
import datetime
import logging
from openpyxl.utils.exceptions import InvalidFileException

logger = logging.getLogger(__name__)

class ExcelParser:
    """Class for parsing Excel files and extracting basic metadata."""
    
    def __init__(self, file_path):
        """Initialize with the path to an Excel file."""
        self.file_path = file_path
        self.workbook = None
        self.metadata = {
            'file_name': os.path.basename(file_path),
            'file_path': os.path.abspath(file_path),
            'file_size': os.path.getsize(file_path),
            'created_date': None,
            'modified_date': None,
            'author': None,
            'sheet_count': 0,
            'has_macros': False
        }
        
    def parse(self):
        """Parse the Excel file and extract metadata."""
        try:
            # Check file size
            if not os.path.exists(self.file_path):
                raise FileNotFoundError(f"File not found: {self.file_path}")
                
            # Get file timestamps
            self.metadata['created_date'] = datetime.datetime.fromtimestamp(
                os.path.getctime(self.file_path))
            self.metadata['modified_date'] = datetime.datetime.fromtimestamp(
                os.path.getmtime(self.file_path))
                
            # Load workbook
            try:
                self.workbook = openpyxl.load_workbook(
                    self.file_path, read_only=True, keep_vba=True, data_only=False)
                
                # Extract metadata
                self._extract_workbook_metadata()
                
                # Get sheet count
                self.metadata['sheet_count'] = len(self.workbook.sheetnames)
                
                logger.info(f"Successfully parsed Excel file: {self.file_path}")
                return self.metadata
            except InvalidFileException:
                # If openpyxl fails, try with pandas
                logger.warning(f"Could not parse with openpyxl, trying pandas: {self.file_path}")
                self._parse_with_pandas()
                return self.metadata
                
        except Exception as e:
            logger.error(f"Error parsing Excel file {self.file_path}: {e}")
            raise
            
    def _extract_workbook_metadata(self):
        """Extract metadata from the openpyxl workbook."""
        # Check if file has macros (is .xlsm)
        self.metadata['has_macros'] = self.workbook.vba_archive is not None
        
        # Get file properties
        if hasattr(self.workbook, 'properties'):
            props = self.workbook.properties
            if props.creator:
                self.metadata['author'] = props.creator
                
    def _parse_with_pandas(self):
        """Parse Excel file using pandas."""
        try:
            # Read Excel file with pandas
            xls = pd.ExcelFile(self.file_path)
            self.metadata['sheet_count'] = len(xls.sheet_names)
            
            # Check if file extension suggests it contains macros
            file_ext = os.path.splitext(self.file_path)[1].lower()
            self.metadata['has_macros'] = file_ext in ['.xlsm', '.xls']
            
        except Exception as e:
            logger.error(f"Error parsing Excel file with pandas {self.file_path}: {e}")
            raise
            
    def get_sheet_names(self):
        """Get the names of all sheets in the workbook."""
        if self.workbook:
            return self.workbook.sheetnames
        return []
        
    def read_sheet_data(self, sheet_name=None):
        """Read data from a specific sheet or all sheets."""
        data = {}
        
        try:
            if not sheet_name:
                # Read all sheets
                for sheet in self.get_sheet_names():
                    df = pd.read_excel(self.file_path, sheet_name=sheet)
                    data[sheet] = df
            else:
                # Read specific sheet
                df = pd.read_excel(self.file_path, sheet_name=sheet_name)
                data[sheet_name] = df
                
            return data
        except Exception as e:
            logger.error(f"Error reading sheet data from {self.file_path}: {e}")
            raise
            
    def close(self):
        """Close the workbook to free resources."""
        if self.workbook:
            self.workbook.close()
