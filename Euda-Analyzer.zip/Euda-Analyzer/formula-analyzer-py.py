import openpyxl
import pandas as pd
import re
import logging
from openpyxl.utils.exceptions import InvalidFileException

logger = logging.getLogger(__name__)

class FormulaAnalyzer:
    """Class for analyzing Excel formulas."""
    
    def __init__(self, file_path):
        """Initialize with the path to an Excel file."""
        self.file_path = file_path
        self.workbook = None
        self.formulas = []
        
    def analyze(self):
        """Analyze the formulas in the Excel file."""
        try:
            # Load workbook with formulas preserved
            self.workbook = openpyxl.load_workbook(self.file_path, data_only=False)
            
            # Analyze each sheet
            for sheet_name in self.workbook.sheetnames:
                sheet = self.workbook[sheet_name]
                self._analyze_sheet_formulas(sheet, sheet_name)
                
            logger.info(f"Analyzed {len(self.formulas)} formulas in {self.file_path}")
            return self.formulas
        except InvalidFileException:
            logger.warning(f"Could not parse with openpyxl, attempting alternative approach: {self.file_path}")
            return self._analyze_with_pandas()
        except Exception as e:
            logger.error(f"Error analyzing formulas: {e}")
            return []
        finally:
            if self.workbook:
                self.workbook.close()
                
    def _analyze_sheet_formulas(self, sheet, sheet_name):
        """Analyze formulas in a single sheet."""
        # Iterate through all cells in the sheet
        for row in sheet