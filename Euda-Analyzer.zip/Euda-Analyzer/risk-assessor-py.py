import re
import logging
from src.config import SENSITIVITY_KEYWORDS

logger = logging.getLogger(__name__)

class RiskAssessor:
    """Class for assessing the risk and data sensitivity of EUDAs."""
    
    def __init__(self):
        """Initialize the risk assessor."""
        self.risk_factors = {
            'macro_risk': 0.25,           # Weight for macro risk
            'connection_sensitivity': 0.20,  # Weight for connection sensitivity
            'data_sensitivity': 0.25,     # Weight for detected sensitive data
            'complexity': 0.15,           # Weight for overall complexity
            'external_connections': 0.15  # Weight for presence of external connections
        }
        
    def assess_risk(self, euda_data, complexity_result):
        """Calculate the overall risk score and sensitivity for an EUDA.
        
        Args:
            euda_data: Dictionary containing EUDA analysis data
            complexity_result: Result from complexity calculation
            
        Returns:
            Dict with risk_score, data_sensitivity, and risk_factors
        """
        try:
            # Extract all text content for sensitivity scanning
            text_content = self._extract_text_content(euda_data)
            
            # Calculate data sensitivity
            data_sensitivity = self._assess_data_sensitivity(text_content)
            
            # Calculate macro risk
            macros = euda_data.get('macros', [])
            macro_risk = self._calculate_macro_risk(macros)
            
            # Calculate connection sensitivity
            connections = euda_data.get('connections', [])
            connection_sensitivity = self._calculate_connection_sensitivity(connections)
            
            # Get external connection factor
            has_external = bool(connections)
            external_factor = 0.8 if has_external else 0.1
            
            # Get complexity factor
            complexity_score = complexity_result.get('complexity_score', 0.5)
            
            # Calculate weighted risk score
            risk_factors = {
                'macro_risk': macro_risk,
                'connection_sensitivity': connection_sensitivity,
                'data_sensitivity': data_sensitivity['score'],
                'complexity': complexity_score,
                'external_connections': external_factor
            }
            
            weighted_score = sum(factor * self.risk_factors[name] for name, factor in risk_factors.items())
            
            # Create result
            result = {
                'risk_score': weighted_score,
                'data_sensitivity': data_sensitivity['level'],
                'risk_factors': self._get_top_risk_factors(risk_factors, self.risk_factors),
                'sensitive_data_types': data_sensitivity['detected_types']
            }
            
            logger.info(f"Assessed risk: {weighted_score:.2f}, Sensitivity: {data_sensitivity['level']}")
            return result
            
        except Exception as e:
            logger.error(f"Error assessing risk: {e}")
            return {
                'risk_score': 0.5,  # Default to medium
                'data_sensitivity': 'medium',
                'risk_factors': ['Error in risk assessment'],
                'sensitive_data_types': []
            }
            
    def _extract_text_content(self, euda_data):
        """Extract all text content from the EUDA for sensitivity analysis."""
        text_content = []
        
        # Extract macro code
        for macro in euda_data.get('macros', []):
            if isinstance(macro, dict) and 'macro_code' in macro:
                text_content.append(macro['macro_code'])
                
        # Extract formula text
        for formula in euda_data.get('formulas', []):
            if isinstance(formula, dict) and 'formula_text' in formula:
                text_content.append(formula['formula_text'])
                
        # Extract connection strings
        for conn in euda_data.get('connections', []):
            if isinstance(conn, dict) and 'connection_string' in conn:
                text_content.append(conn['connection_string'])
                
        # Add sheet data if available
        for sheet_name, sheet_data in euda_data.get('sheet_data', {}).items():
            if isinstance(sheet_data, dict):
                for cell, value in sheet_data.items():
                    if isinstance(value, str):
                        text_content.append(value)
                        
        return ' '.join(text_content)
        
    def _assess_data_sensitivity(self, text):
        """Assess the sensitivity of data based on content analysis."""
        if not text:
            return {'level': 'low', 'score': 0.1, 'detected_types': []}
            
        text_lower = text.lower()
        detected_types = []
        
        # Check for patterns of sensitive data
        patterns = {
            'Social Security Number': r'\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b',
            'Credit Card': r'\b(?:\d{4}[-\s]?){3}\d{4}\b',
            'Email Address': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'Phone Number': r'\b\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b',
            'IP Address': r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b'
        }
        
        # Check for each pattern
        for data_type, pattern in patterns.items():
            if re.search(pattern, text):
                detected_types.append(data_type)
                
        # Check for keyword-based sensitivity
        high_matches = 0
        medium_matches = 0
        low_matches = 0
        
        for keyword in SENSITIVITY_KEYWORDS['high']:
            if re.search(r'\b' + re.escape(keyword) + r'\b', text_lower):
                high_matches += 1
                
        for keyword in SENSITIVITY_KEYWORDS['medium']:
            if re.search(r'\b' + re.escape(keyword) + r'\b', text_lower):
                medium_matches += 1
                
        for keyword in SENSITIVITY_KEYWORDS['low']:
            if re.search(r'\b' + re.escape(keyword) + r'\b', text_lower):
                low_matches += 1
                
        # Determine sensitivity score and level
        sensitivity_score = (high_matches * 0.1 + medium_matches * 0.05 + low_matches * 0.01)
        # Cap at 1.0
        sensitivity_score = min(1.0, sensitivity_score)
        
        # Add pattern-based detection bonus
        if detected_types:
            sensitivity_score = max(sensitivity_score, 0.7)  # Minimum high score with pattern matches
            
        # Determine sensitivity level
        if sensitivity_score > 0.6 or high_matches > 3 or len(detected_types) > 1:
            level = 'high'
        elif sensitivity_score > 0.3 or medium_matches > 5 or detected_types:
            level = 'medium'
        else:
            level = 'low'
            
        return {
            'level': level,
            'score': sensitivity_score,
            'detected_types': detected_types
        }
        
    def _calculate_macro_risk(self, macros):
        """Calculate the risk score associated with macros."""
        if not macros:
            return 0
            
        # Extract risk scores
        risk_scores = []
        for macro in macros:
            if isinstance(macro, dict) and 'risk_score' in macro:
                risk_scores.append(macro['risk_score'])
                
        # Calculate average (or return 0 if no scores found)
        # We use max because a single high-risk macro makes the whole file high risk
        return max(risk_scores) if risk_scores else 0
        
    def _calculate_connection_sensitivity(self, connections):
        """Calculate a score representing the overall sensitivity of connections."""
        if not connections:
            return 0
            
        # Map sensitivity levels to scores
        sensitivity_scores = {'low': 0.3, 'medium': 0.6, 'high': 1.0}
        
        # Extract sensitivity levels
        scores = []
        for conn in connections:
            if isinstance(conn, dict) and 'sensitivity_level' in conn:
                level = conn['sensitivity_level']
                scores.append(sensitivity_scores.get(level, 0.5))
                
        # Calculate maximum (or return 0 if no scores found)
        # We use max because a single high-sensitivity connection elevates the risk
        return max(scores) if scores else 0
        
    def _get_top_risk_factors(self, risk_factors, weights):
        """Identify the top contributing factors to risk."""
        # Calculate weighted contribution for each factor
        weighted_contributions = {
            factor: value * weights[factor]
            for factor, value in risk_factors.items()
        }
        
        # Sort factors by their contribution (descending)
        sorted_factors = sorted(
            weighted_contributions.items(),
            key=lambda x: x[1],
            reverse=True
        )
        
        # Return the top 3 contributing factors
        top_factors = [factor for factor, _ in sorted_factors[:3] if _ > 0.1]
        
        return top_factors
