import os
import json
import boto3
import logging
import numpy as np

logger = logging.getLogger(__name__)

class VectorEmbedder:
    """Class for creating vector embeddings from EUDA analysis using Amazon Titan models."""
    
    def __init__(self):
        """Initialize the embedder with Amazon Bedrock client."""
        self.bedrock_client = boto3.client(
            service_name='bedrock-runtime',
            region_name=os.getenv('AWS_REGION', 'us-east-1')
        )
        self.text_model_id = os.getenv('TITAN_TEXT_MODEL_ID', 'amazon.titan-text-embed-v2:0')
        self.image_model_id = os.getenv('TITAN_IMAGE_MODEL_ID', 'amazon.titan-image-v1')
        logger.info(f"Vector embedder initialized with text model: {self.text_model_id}")
    
    def embed_text(self, text):
        """Create an embedding for the given text using Amazon Titan text model."""
        try:
            # Truncate text if it's too long (Titan has a token limit)
            if len(text) > 8000:  # Approximate token limit
                logger.warning(f"Text too long ({len(text)} chars), truncating to 8000 chars")
                text = text[:8000]
            
            request_body = json.dumps({
                "inputText": text
            })
            
            response = self.bedrock_client.invoke_model(
                modelId=self.text_model_id,
                contentType='application/json',
                accept='application/json',
                body=request_body
            )
            
            response_body = json.loads(response.get('body').read())
            embedding = response_body.get('embedding')
            
            return embedding
        except Exception as e:
            logger.error(f"Error creating text embedding: {str(e)}")
            # Return a zero vector as fallback
            return [0.0] * 1536  # Typical embedding dimension
    
    def embed_analysis(self, analysis):
        """Create an embedding for the EUDA analysis."""
        # Create a text representation of the analysis
        text_representation = self._create_text_representation(analysis)
        
        # Get embedding for the text
        embedding = self.embed_text(text_representation)
        
        return embedding
    
    def _create_text_representation(self, analysis):
        """Convert the analysis dictionary to a text representation for embedding."""
        sections = [
            f"Filename: {analysis['filename']}",
            f"Summary: {analysis['summary']}",
            
            "Complexity Analysis:",
            f"- Total Complexity Score: {analysis['complexity']['total_score']}",
            f"- Sheet Count: {analysis['complexity']['sheet_count']}",
            f"- Cell Count: {analysis['complexity']['cell_count']}",
            f"- Formula Complexity: {analysis['complexity']['formula_complexity']}",
            
            "Risk Assessment:",
            f"- Risk Level: {analysis['risk_assessment']['risk_level']}",
            f"- Contains Sensitive Data: {analysis['risk_assessment']['contains_sensitive_data']}",
            f"- Compliance Issues: {', '.join(analysis['risk_assessment']['compliance_issues'])}",
            
            "Connections Analysis:",
            f"- Has External Connections: {analysis['connections']['has_external_connections']}",
            f"- Data Sources: {', '.join(analysis['connections']['data_sources'])}",
            
            "Formula Analysis:",
            f"- Total Formulas: {analysis['formulas']['total_count']}",
            f"- Complex Formulas: {analysis['formulas']['complex_formulas_count']}",
            f"- Formula Types: {', '.join(analysis['formulas']['formula_types'])}",
            
            "Macro Analysis:",
            f"- Has Macros: {analysis['macros']['has_macros']}",
            f"- Number of Macros: {len(analysis['macros']['macros'])}"
        ]
        
        # Add macro details if there are macros
        if analysis['macros']['has_macros']:
            macro_details = []
            for macro in analysis['macros']['macros']:
                macro_details.append(f"- {macro['name']}: {macro['description']}")
            sections.append("Macro Details:")
            sections.extend(macro_details)
        
        return "\n".join(sections)
