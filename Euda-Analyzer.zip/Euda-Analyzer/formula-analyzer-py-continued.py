def _analyze_sheet_formulas(self, sheet, sheet_name):
        """Analyze formulas in a single sheet."""
        # Iterate through all cells in the sheet
        for row in sheet.iter_rows():
            for cell in row:
                if cell.data_type == 'f':  # Cell contains a formula
                    formula_text = cell.value
                    if formula_text and formula_text.startswith('='):
                        formula_info = {
                            'sheet_name': sheet_name,
                            'cell_reference': cell.coordinate,
                            'formula_text': formula_text,
                            'complexity_score': self._calculate_formula_complexity(formula_text)
                        }
                        self.formulas.append(formula_info)
                        
    def _analyze_with_pandas(self):
        """Alternative formula analysis using pandas."""
        try:
            # Use ExcelFile to access sheet names
            excel_file = pd.ExcelFile(self.file_path)
            
            # Process each sheet
            for sheet_name in excel_file.sheet_names:
                # We need to find a way to extract formulas
                # Unfortunately, pandas doesn't directly expose formulas
                # This is a limitation of the pandas approach
                
                # We'll do a basic check for possible formula patterns in the raw file
                try:
                    with open(self.file_path, 'rb') as file:
                        content = file.read().decode('latin-1')
                        # Look for formula patterns (very basic approach)
                        formula_matches = re.findall(r'([A-Z]+[0-9]+:[A-Z]+[0-9]+|[A-Z]+\([^)]+\))', content)
                        
                        for i, match in enumerate(formula_matches):
                            formula_info = {
                                'sheet_name': sheet_name,
                                'cell_reference': f'Unknown_{i+1}',
                                'formula_text': f'=Unknown(possibly includes {match})',
                                'complexity_score': 0.5  # Default medium complexity
                            }
                            self.formulas.append(formula_info)
                except Exception as e:
                    logger.warning(f"Couldn't perform raw formula extraction: {e}")
            
            logger.info(f"Found {len(self.formulas)} potential formula patterns (limited analysis)")
            return self.formulas
        except Exception as e:
            logger.error(f"Error in pandas formula analysis: {e}")
            return []
            
    def _calculate_formula_complexity(self, formula):
        """Calculate complexity score for a formula."""
        if not formula:
            return 0
            
        # Formula length is a basic complexity indicator
        length_factor = min(1.0, len(formula) / 200)  # Cap at formula length of 200
        
        # Count nested functions
        nested_count = formula.count('(')
        nested_factor = min(1.0, nested_count / 10)  # Cap at 10 nested functions
        
        # Check for advanced functions
        advanced_functions = [
            'INDEX', 'MATCH', 'VLOOKUP', 'HLOOKUP', 'SUMIFS', 'COUNTIFS', 
            'SUMPRODUCT', 'INDIRECT', 'OFFSET', 'LOOKUP', 'CHOOSE', 'IF'
        ]
        
        # Count occurrences of advanced functions
        advanced_count = sum(formula.upper().count(func) for func in advanced_functions)
        advanced_factor = min(1.0, advanced_count / 5)  # Cap at 5 advanced functions
        
        # Check for array formulas
        array_factor = 0.2 if '{' in formula and '}' in formula else 0
        
        # Combined score (0-1 scale)
        complexity_score = (
            0.25 * length_factor + 
            0.35 * nested_factor + 
            0.30 * advanced_factor + 
            0.10 * array_factor
        )
        
        return min(1.0, max(0.1, complexity_score))  # Ensure between 0.1 and 1.0
        
    def get_formulas_summary(self):
        """Get a summary of formula usage in the workbook."""
        if not self.formulas:
            return "No formulas found in the workbook."
            
        # Count formulas by sheet
        sheet_counts = {}
        for formula in self.formulas:
            sheet_name = formula['sheet_name']
            sheet_counts[sheet_name] = sheet_counts.get(sheet_name, 0) + 1
            
        # Get average complexity
        avg_complexity = sum(f['complexity_score'] for f in self.formulas) / len(self.formulas)
        
        # Identify most complex formulas
        sorted_formulas = sorted(self.formulas, key=lambda x: x['complexity_score'], reverse=True)
        most_complex = sorted_formulas[:3] if len(sorted_formulas) >= 3 else sorted_formulas
        
        # Prepare summary
        summary = f"Total formulas: {len(self.formulas)}\n"
        summary += f"Average complexity: {avg_complexity:.2f}\n"
        summary += "Formulas by sheet:\n"
        
        for sheet, count in sheet_counts.items():
            summary += f"  - {sheet}: {count}\n"
            
        summary += "Most complex formulas:\n"
        for i, formula in enumerate(most_complex):
            summary += f"  {i+1}. {formula['cell_reference']} in {formula['sheet_name']}: {formula['formula_text'][:50]}...\n"
            
        return summary
