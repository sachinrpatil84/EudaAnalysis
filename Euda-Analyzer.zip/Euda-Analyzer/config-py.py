import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Database configuration
DB_CONFIG = {
    'host': os.getenv('PG_HOST', 'localhost'),
    'port': int(os.getenv('PG_PORT', 5432)),
    'user': os.getenv('PG_USER', 'postgres'),
    'password': os.getenv('PG_PASSWORD', ''),
    'database': os.getenv('PG_DATABASE', 'euda_analyzer')
}

# AWS configuration
AWS_CONFIG = {
    'aws_access_key_id': os.getenv('AWS_ACCESS_KEY_ID'),
    'aws_secret_access_key': os.getenv('AWS_SECRET_ACCESS_KEY'),
    'region_name': os.getenv('AWS_REGION', 'us-east-1')
}

# Embedding models
TEXT_EMBEDDING_MODEL = "amazon-titan-text-v2:0"
IMAGE_EMBEDDING_MODEL = "amazon-titan-image-v1"

# Analysis settings
MAX_EXCEL_FILE_SIZE = 100 * 1024 * 1024  # 100 MB
COMPLEXITY_THRESHOLDS = {
    'low': 30,
    'medium': 70,
    'high': 100
}

# Sensitivity classification keywords
SENSITIVITY_KEYWORDS = {
    'high': ['ssn', 'social security', 'password', 'credit card', 'address', 'dob', 'birth date', 
             'personal', 'confidential', 'private', 'secret', 'restricted'],
    'medium': ['email', 'phone', 'customer', 'client', 'employee', 'finance', 'payment', 
               'salary', 'revenue', 'profit'],
    'low': ['public', 'open', 'general', 'common']
}

# Database schema
VECTOR_DIMENSION = 1536  # Titan embeddings size
