import os
import json
import argparse
import logging
from dotenv import load_dotenv
import boto3
from db_connector import DbConnector

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("euda_query.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class EudaQueryApp:
    """Application for querying EUDA analysis data using LLM."""
    
    def __init__(self):
        """Initialize the query application."""
        self.db = DbConnector()
        self.bedrock_client = boto3.client(
            service_name='bedrock-runtime',
            region_name=os.getenv('AWS_REGION', 'us-east-1')
        )
        self.llm_model_id = os.getenv('LLM_MODEL_ID', 'anthropic.claude-3-sonnet-20240229-v1:0')
        logger.info(f"EUDA Query App initialized with LLM model: {self.llm_model_id}")
    
    def query(self, user_query, max_results=3):
        """
        Process a user query about EUDAs and provide a response using vector search and LLM.
        
        Args:
            user_query (str): The user's question about EUDAs
            max_results (int): Maximum number of similar EUDAs to retrieve
            
        Returns:
            str: The LLM-generated response to the user's query
        """
        logger.info(f"Processing query: {user_query}")
        
        # Search for similar EUDAs in the vector database
        similar_eudas = self.db.search_similar_eudas(user_query, limit=max_results)
        
        if not similar_eudas:
            return "I couldn't find any relevant EUDA information in the database to answer your query."
        
        # Get full analysis data for the similar EUDAs
        euda_details = []
        for euda in similar_eudas:
            full_analysis = self.db.get_analysis_by_id(euda['id'])
            if full_analysis:
                euda_details.append(full_analysis)
        
        # Prepare context for the LLM
        context = self._prepare_llm_context(user_query, euda_details)
        
        # Generate response using the LLM
        response = self._generate_llm_response(context)
        
        return response
    
    def _prepare_llm_context(self, user_query, euda_details):
        """Prepare the context for the LLM query."""
        euda_summaries = []
        
        for i, euda in enumerate(euda_details, 1):
            summary = f"EUDA #{i}: {euda['filename']}\n"
            summary += f"Summary: {euda['summary']}\n"
            summary += f"Complexity Score: {euda['complexity']['total_score']}\n"
            summary += f"Risk Level: {euda['risk_assessment']['risk_level']}\n"
            
            if euda['risk_assessment']['contains_sensitive_data']:
                summary += "Contains sensitive data: Yes\n"
            
            if euda['connections']['has_external_connections']:
                sources = ", ".join(euda['connections']['data_sources'])
                summary += f"External data sources: {sources}\n"
            
            if euda['macros']['has_macros']:
                macro_count = len(euda['macros']['macros'])
                summary += f"Contains {macro_count} macros\n"
            
            summary += f"Formula count: {euda['formulas']['total_count']}\n"
            
            euda_summaries.append(summary)
        
        context = f"""
        User Query: {user_query}
        
        Relevant EUDA Information:
        
        {"".join(euda_summaries)}
        
        Based on the information above, please provide a helpful response to the user's query about EUDAs. 
        If the information is not sufficient to answer the query directly, provide the most relevant insights available.
        
        Focus on remediation strategies, suggestions for improving EUDAs, risk mitigation, and best practices where appropriate.
        If the question is about specific EUDAs, provide details about their complexity, risk level, data sources, and functionality.
        """
        
        return context
    
    def _generate_llm_response(self, context):
        """Generate a response using the LLM."""
        try:
            request_body = json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 1000,
                "messages": [
                    {
                        "role": "user",
                        "content": context
                    }
                ]
            })
            
            response = self.bedrock_client.invoke_model(
                modelId=self.llm_model_id,
                contentType='application/json',
                accept='application/json',
                body=request_body
            )
            
            response_body = json.loads(response.get('body').read())
            llm_response = response_body['content'][0]['text']
            
            return llm_response
        except Exception as e:
            logger.error(f"Error generating LLM response: {str(e)}")
            return f"I encountered an error while generating a response: {str(e)}"
    
    def interactive_mode(self):
        """Run the query app in interactive mode."""
        print("EUDA Query Application")
        print("Type 'exit' or 'quit' to end the session.")
        
        while True:
            user_query = input("\nEnter your query about EUDAs: ")
            if user_query.lower() in ['exit', 'quit']:
                break
            
            response = self.query(user_query)
            print("\nResponse:")
            print(response)
    
    def close(self):
        """Close connections and resources."""
        self.db.close()
        logger.info("EUDA Query App resources closed")

def main():
    """Main function to run the EUDA query application."""
    load_dotenv()
    
    parser = argparse.ArgumentParser(description='EUDA Query Application')
    parser.add_argument('--query', help='Query to process (if not provided, runs in interactive mode)')
    args = parser.parse_args()
    
    app = EudaQueryApp()
    
    try:
        if args.query:
            response = app.query(args.query)
            print(response)
        else:
            app.interactive_mode()
    finally:
        app.close()

if __name__ == '__main__':
    main()
