import logging
from src.config import COMPLEXITY_THRESHOLDS

logger = logging.getLogger(__name__)

class ComplexityCalculator:
    """Class for calculating the overall complexity of EUDA files."""
    
    def __init__(self):
        """Initialize the complexity calculator."""
        self.complexity_factors = {
            'file_size': 0.05,           # Weight for file size
            'sheet_count': 0.05,         # Weight for number of sheets
            'formula_count': 0.15,       # Weight for number of formulas
            'formula_complexity': 0.20,  # Weight for formula complexity
            'macro_count': 0.10,         # Weight for number of macros
            'macro_complexity': 0.25,    # Weight for macro complexity
            'connection_count': 0.10,    # Weight for number of connections
            'connection_sensitivity': 0.10  # Weight for connection sensitivity
        }
        
    def calculate_complexity(self, euda_data):
        """Calculate the overall complexity score for an EUDA.
        
        Args:
            euda_data: Dictionary containing EUDA analysis data
            
        Returns:
            Dict with complexity_score and complexity_level
        """
        try:
            # Extract required data with defaults for missing values
            file_size = euda_data.get('file_size', 0)
            sheet_count = euda_data.get('sheet_count', 0)
            
            formulas = euda_data.get('formulas', [])
            formula_count = len(formulas)
            formula_complexity = self._average_complexity(formulas)
            
            macros = euda_data.get('macros', [])
            macro_count = len(macros)
            macro_complexity = self._average_complexity(macros)
            
            connections = euda_data.get('connections', [])
            connection_count = len(connections)
            connection_sensitivity = self._calculate_connection_sensitivity(connections)
            
            # Normalize each factor to a 0-1 scale
            normalized_factors = {
                'file_size': min(1.0, file_size / (10 * 1024 * 1024)),  # Normalize to 10MB
                'sheet_count': min(1.0, sheet_count / 20),  # Normalize to 20 sheets
                'formula_count': min(1.0, formula_count / 500),  # Normalize to 500 formulas
                'formula_complexity': formula_complexity,
                'macro_count': min(1.0, macro_count / 20),  # Normalize to 20 macros
                'macro_complexity': macro_complexity,
                'connection_count': min(1.0, connection_count / 10),  # Normalize to 10 connections
                'connection_sensitivity': connection_sensitivity
            }
            
            # Calculate weighted score
            weighted_score = 0
            for factor, weight in self.complexity_factors.items():
                weighted_score += normalized_factors[factor] * weight
                
            # Determine complexity level
            complexity_level = self._determine_complexity_level(weighted_score)
            
            # Create detailed result
            result = {
                'complexity_score': weighted_score,
                'complexity_level': complexity_level,
                'contributing_factors': self._get_contributing_factors(normalized_factors, self.complexity_factors)
            }
            
            logger.info(f"Calculated complexity: {complexity_level} ({weighted_score:.2f})")
            return result
            
        except Exception as e:
            logger.error(f"Error calculating complexity: {e}")
            return {
                'complexity_score': 0.5,  # Default to medium
                'complexity_level': 'medium',
                'contributing_factors': ['Error in complexity calculation']
            }
            
    def _average_complexity(self, items):
        """Calculate the average complexity score from a list of items."""
        if not items:
            return 0
            
        # Extract complexity scores
        complexity_scores = []
        for item in items:
            if isinstance(item, dict) and 'complexity_score' in item:
                complexity_scores.append(item['complexity_score'])
                
        # Calculate average (or return 0 if no scores found)
        return sum(complexity_scores) / len(complexity_scores) if complexity_scores else 0
        
    def _calculate_connection_sensitivity(self, connections):
        """Calculate a score representing the overall sensitivity of connections."""
        if not connections:
            return 0
            
        # Map sensitivity levels to scores
        sensitivity_scores = {'low': 0.3, 'medium': 0.6, 'high': 1.0}
        
        # Extract sensitivity levels
        scores = []
        for conn in connections:
            if isinstance(conn, dict) and 'sensitivity_level' in conn:
                level = conn['sensitivity_level']
                scores.append(sensitivity_scores.get(level, 0.5))
                
        # Calculate average (or return 0 if no scores found)
        return sum(scores) / len(scores) if scores else 0
        
    def _determine_complexity_level(self, score):
        """Convert a numeric complexity score to a categorical level."""
        if score < COMPLEXITY_THRESHOLDS['low'] / 100:
            return 'low'
        elif score < COMPLEXITY_THRESHOLDS['medium'] / 100:
            return 'medium'
        else:
            return 'high'
            
    def _get_contributing_factors(self, normalized_factors, weights):
        """Identify the top contributing factors to complexity."""
        # Calculate weighted contribution for each factor
        weighted_contributions = {
            factor: value * weights[factor]
            for factor, value in normalized_factors.items()
        }
        
        # Sort factors by their contribution (descending)
        sorted_factors = sorted(
            weighted_contributions.items(),
            key=lambda x: x[1],
            reverse=True
        )
        
        # Return the top 3 contributing factors
        top_factors = [factor for factor, _ in sorted_factors[:3] if _ > 0]
        
        return top_factors
